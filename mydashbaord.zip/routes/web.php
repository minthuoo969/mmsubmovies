<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashController;
use App\Http\Controllers\MovieController;
use App\Http\Controllers\TMDBController;
use App\Http\Controllers\AddMovieController;
use App\Http\Controllers\AddTVcontroller;
use App\Http\Controllers\BulkManager;
use App\Http\Controllers\TvBulk;
use App\Http\Controllers\episodecountroller;
use App\Http\Controllers\MovieVideoController;
use App\Http\Controllers\SeasonManagerController;
use App\Http\Controllers\TVController;
use App\Http\Controllers\GenersController;
use App\Http\Controllers\skipg;
use App\Http\Controllers\UserManager;
use Illuminate\Support\Facades\Route;




Route::middleware('isLogedin')->group(function () {

    Route::controller(MovieController::class)->group(function(){
        Route::get('/movie', 'show')->name('movie');
        Route::get('/movie/{id}', 'deletmovie')->name('deletmovie');

        //Route::get('addmovie', 'create')->name('addmovie');

        //Route::post('/movie/addmovie', 'addmovie')->name('addmovie.post');

        //Route::get('/movie/addmovie', 'getMovieFromeTMDB')->name('FromeTMDB');



    });

    Route::get('/', [DashController::class, 'show'])->name('dash');
    Route::view('/subscrib', 'layout.subscrib')->name('subscrib');
    Route::view('/setting', 'layout.settings')->name('settings');
    Route::get('/gettmdb', [TMDBController::class, 'demo'])->name('showtmdb');


    Route::get('/addmovie', [AddMovieController::class, 'create'])->name('addmovie');
    Route::post('/addmovie', [AddMovieController::class, 'getMovieFromTMDB'])->name('getMovieFromTMDB');
    Route::post('/movie', [AddMovieController::class, 'createmovie'])->name('createmovie');
    Route::get('/editmovie/{id}', [AddMovieController::class, 'editmoviecreate'])->name('editmoviecreate');
    Route::put('/editmovie/{id}', [AddMovieController::class, 'editmovie'])->name('editmovie');


    Route::get('/manage_movie_links/{id}', [MovieVideoController::class, 'create'])->name('showmoviemanager');
    Route::post('/manage_movie_links/{id}', [MovieVideoController::class, 'storevideo'])->name('storevideo');
    Route::get('/delet_manage_movie_links/{id}', [MovieVideoController::class, 'deletvideo'])->name('deletvideo');




    /*******************  TV  **********************/


    Route::get('/tv', [TVController::class, 'create'])->name('tv');
    Route::get('/addtv', [AddTVcontroller::class, 'create'])->name('addtv');
    Route::post('/addtv', [AddTVcontroller::class, 'gettvFromTMDB'])->name('gettvFromTMDB');
    Route::post('/tv', [AddTVcontroller::class, 'addtv'])->name('Addtv.post');
    Route::get('/edit_tv/{id}', [AddTVcontroller::class, 'edittvcreate'])->name('edittvcreate');
    Route::put('/edit_tv/{id}', [AddTVcontroller::class, 'edittv'])->name('edittv');
    Route::get('/delettv/{id}', [AddTVcontroller::class, 'delettv'])->name('delettv');


    Route::get('/manage_seasons/{id}', [SeasonManagerController::class, 'create'])->name('managerseason.create');
    //Route::post('/manage_seasons/{id}', [SeasonManagerController::class, 'addseason'])->name('addseason');
    Route::post('/manage_seasons/{id}', [SeasonManagerController::class, 'addseason'])->name('fetchallseason');
    Route::get('/delet_seasons/{id}', [SeasonManagerController::class, 'deletseason'])->name('deletseason');
    Route::get('/getSeasonsFromTMDB/{id}', [SeasonManagerController::class, 'getSeasonsFromTMDB'])->name('getSeasonsFromTMDB');

    


    Route::get('/manage_tv_episdoe/{id}', [episodecountroller::class, 'create'])->name('showepisodes');
    Route::post('/manage_tv_episdoe/{id}', [episodecountroller::class, 'storevideo'])->name('storevideo');
    Route::get('/delet_tv_episdoe/{id}', [episodecountroller::class, 'deleepisodeideo'])->name('deleepisodeideo');



     /*******************  GENERS  **********************/


     Route::get('/geners', [GenersController::class, 'create'])->name('geners');
     Route::post('/geners', [GenersController::class, 'addgeners'])->name('addgeners');
     Route::get('/delet_geners/{id}', [GenersController::class, 'delet'])->name('deletgener');
     Route::put('/edit_geners/{id}', [GenersController::class, 'editGener'])->name('editGener');

     /*******************  USERS  **********************/

     Route::get('/users', [UserManager::class, 'Show'])->name('users');
     Route::post('/users', [UserManager::class, 'AddUser'])->name('AddUser');
     Route::get('/delet_user/{id}', [UserManager::class, 'DeletUser'])->name('DeletUser');

     /*******************  Skip Google  **********************/

     Route::resource('skipgoogle', skipg::class)->name('index','skipg')->name('store','saveinfo');
     Route::resource('bulk', BulkManager::class)->name('index','getbulkview')->name('store','savebulk');
     Route::get('tvbulk', [TvBulk::class, 'tvshowsbulk'])->name('tvshowsbulk');
     Route::post('tvbulk', [TvBulk::class, 'savetvshowsbulk'])->name('savetvshowsbulk');

     
     
     
     
     


});





/*---------------------------- Auth ---------------------------- */


Route::controller(AuthController::class)->group(function(){

    Route::get('/login', 'login')->name('login')->middleware('AlreadyLoggedIn');
    Route::post('/login', 'loginPost')->name('login.post');
    Route::get('/logout',  'logout')->name('logout');

});


