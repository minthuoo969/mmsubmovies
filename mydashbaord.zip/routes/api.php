<?php

use App\Http\Controllers\ApiAuthController;
use App\Http\Controllers\bulkapiController as ControllersBulkapiController;
use App\Http\Controllers\MovieApiController;
use App\Http\Controllers\GenersController;
use App\Http\Controllers\TvApiController;
use App\Http\Resources\bulkapiController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/


Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});



Route::post('/login', [ApiAuthController::class, 'login']);
Route::post('/createacc', [ApiAuthController::class, 'register']);
Route::get('/chackeemail/{email}', [ApiAuthController::class, 'chackeemail']);
Route::get('/logout', [ApiAuthController::class, 'logout']);


Route::resource('movie', MovieApiController::class);
Route::get('/publishedmovie', [MovieApiController::class, 'publishedmovie']);
Route::get('/actionmovie', [MovieApiController::class, 'actionmovie']);
Route::get('/supreheromovie', [MovieApiController::class, 'supreheromovie']);
Route::get('/TrendingMovie', [MovieApiController::class, 'TrendingMovie']);
Route::get('/allmovietv', [MovieApiController::class, 'allmt']);
Route::post('/search/movie/{search}', [MovieApiController::class, 'search']);



// tvs

Route::resource('tv', TvApiController::class);
Route::get('/actiontv', [TvApiController::class, 'actiontv']);
Route::get('/supreherotv', [TvApiController::class, 'supreherotv']);
Route::get('/Trendingtv', [TvApiController::class, 'Trendingtv']);
Route::post('/search/tv/{search}', [TvApiController::class, 'search']);
Route::get('/episdoesofseason/{id}', [TvApiController::class, 'episdoesofseason']);


// more
Route::resource('skipgoogle', ControllersBulkapiController::class);
Route::get('getgeners', [GenersController::class,'getgeners']);




// Route::group(['middleware'=>'auth:sanctum'],function() {

//     Route::resource('movie',MovieApiController::class);
//     Route::get('/publishedmovie',[MovieApiController::class,'publishedmovie']);
//     Route::get('/actionmovie',[MovieApiController::class,'actionmovie']);
//     Route::get('/supreheromovie',[MovieApiController::class,'supreheromovie']);
//     Route::get('/TrendingMovie',[MovieApiController::class,'TrendingMovie']);
//     Route::post('/logout',[ApiAuthController::class,'logout']);

// });
