<!DOCTYPE html>
<!-- Coding By CodingNepal - codingnepalweb.com -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>login | Jserie Admin</title>
    <link rel="stylesheet" href="{{asset('asset/home/css/loginstyle.css')}}">
   </head>
<body>


  <div class="wrapper">

    <div class="top">
        <h2>LOGIN</h2>

    </div>

    <div class="mt-5">
        @if ($errors->any())
            <div class="col-12">
                @foreach ($errors->all() as $error)

                <div >{{$error}}</div>

                @endforeach
            </div>
        @endif
        @if (session()->has('error'))
        <div class="alert alert-danger">{{session('error')}}</div>
        @endif
    </div>

    <form action="{{route('login.post')}}" method="post">
        @csrf
      <div class="input-box">
        <input type="text" placeholder="Email" name="email" value="{{old('email')}}">
      </div>
      <div class="input-box">
        <input type="password" placeholder="Password"  name="password" value="{{old('password')}}">
      </div>


      <div class="input-box button">
        <input type="Submit" value="Login">
      </div>

    </form>
  </div>
  <div class="below">
    <div class="text">
        <h3>Crafted  by <a href="https://codecanyon.net/user/elkadianass"> ANASS CORP</a></h3>
      </div>
  </div>
</body>
</html>
