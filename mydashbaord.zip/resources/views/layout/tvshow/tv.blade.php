@extends('home')

@section('title', 'TV')

@section('contant')



    <div class="container-movies">
        <main>


            <div class="all-movies">

                <section class="movie-section">
                    <div class="sales-analytics">
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end black">
                            <a href="{{route('addtv')}}">
                                <div class="input-box button">
                                    <button form="tm" class="fetch-btn">Add TVSHOW</button>
                                </div>
                            </a>

                        </div>

                        {{-- <div class="item add-product">
                            <div>

                                <a href="{{ route('addmovie') }}">
                                    <span class="material-symbols-sharp">add</span>
                                    <h3>Add Movie</h3>


                                </a>
                            </div>
                        </div> --}}



                        {{--
                    </div>

                         <div class="king">
                        <div class="record-header">
                            <div class="add">
                                <span>Page</span>
                                <select name="" id="">
                                    <option value="">ID</option>
                                </select>

                            </div>

                            <form action="" method="GET">
                                @csrf
                                <div class="browse">

                                    <input type="search" name="query" placeholder="search" class="record-search">

                                </div>
                            </form>

                        </div>
                        <table>

                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>##</th>
                                    <th>Thumbnail</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Status</th>

                                </tr>
                            </thead>
                            <tbody>

                                @if (isset($result))

                                    @foreach ($result as $user)
                                        <tr>
                                            <td>{{ $user['id'] }}</td>
                                            <td class="btn-edit">
                                                <div class="dropdown">
                                                    <div class="select">
                                                        <span class="selected">Options</span>
                                                        <div class="caret"></div>
                                                    </div>
                                                    <ul class="menu">

                                                        <li><a href="{{ route('editmoviecreate', $user['id']) }}">Edit
                                                                Movie</a></li>
                                                        <li><a href="{{ route('showmoviemanager', $user['id']) }}">Manage
                                                                Videos</a></li>
                                                        <li><a href="{{ route('deletmovie', $user['id']) }}">Delete</a></li>
                                                    </ul>
                                                </div>
                                            </td>
                                            <td class="poster"><img src="{{ $user['poster'] }}" alt=""></td>
                                            <td class="mytitle">{{ $user['title'] }}</td>
                                            <td>{{ $user['story'] }}</td>
                                            <td class="warning">{{ $user['place'] }}</td>


                                        </tr>
                                    @endforeach
                                    <div>
                                        {{ $result->links('pagination::bootstrap-4') }}
                                    </div>
                                @else
                                    @foreach ($allmovies as $user)
                                        <tr>
                                            <td>{{ $user['id'] }}</td>
                                            <td class="btn-edit">
                                                <div class="dropdown">
                                                    <div class="select">
                                                        <span class="selected">Options</span>
                                                        <div class="caret"></div>
                                                    </div>
                                                    <ul class="menu">

                                                        <li><a href="{{ route('editmoviecreate', $user['id']) }}">Edit
                                                                Movie</a></li>
                                                        <li><a href="{{ route('showmoviemanager', $user['id']) }}">Manage
                                                                Videos</a></li>
                                                        <li><a href="{{ route('deletmovie', $user['id']) }}">Delete</a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </td>
                                            <td class="poster"><img src="{{ $user['poster'] }}" alt=""></td>
                                            <td class="mytitle">{{ $user['title'] }}</td>
                                            <td>{{ $user['story'] }}</td>
                                            <td class="warning">{{ $user['place'] }}</td>


                                        </tr>
                                    @endforeach


                                @endif


                            </tbody>

                        </table>
                        <div class="mynav">
                            {{ $allmovies->links('pagination::bootstrap-4') }}
                        </div>
                    </div> --}}



                </section>




            </div>

            <div class="container-fluid mt-5 bg-white p-4 rounded shadow">
                <div class="d-flex justify-content-between">
                    <div>
                        <h1>All TVSHOWS</h1>
                        <form action="" method="GET">
                            @csrf
                            <div class="browse">

                                <input type="search" name="query" placeholder="search" class="record-search">

                            </div>
                        </form>
                    </div>
                    <div>
                        <span class="fs-6 badge rounded-pill text-bg-dark">
                            Total TVSHOWS : {{ count($allmovies) }}
                        </span>
                    </div>

                </div>

                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Options</th>
                            <th scope="col">Thumbnail</th>
                            <th scope="col">Name</th>
                            <th scope="col">Description</th>
                            <th scope="col">Status</th>
                        </tr>
                    </thead>

                    @if (isset($result))
                    <tbody>
                        @foreach ($result as $user)
                            <tr>
                                <td>{{ $user['id'] }}</td>
                                <td class="btn-edit">
                                    <div class="dropdown">
                                        <div class="select">
                                            <span class="selected">Options</span>
                                            <div class="caret"></div>
                                        </div>
                                        <ul class="menu">

                                            <li><a href="{{ route('edittvcreate', $user['id']) }}">Edit
                                                    TV</a></li>
                                            <li><a href="{{ route('managerseason.create', $user['id']) }}">Manage
                                                    Seasons</a></li>
                                            <li><a href="{{ route('delettv', $user['id']) }}">Delete</a></li>
                                        </ul>
                                    </div>
                                </td>
                                <td class="poster"><img src="{{ $user['poster'] }}" alt=""></td>
                                <td class="mytitle">{{ $user['title'] }}</td>
                                <td>{{ $user['story'] }}</td>
                                <td class="warning">{{ $user['place'] }}</td>


                            </tr>
                        @endforeach

                    </tbody>

                    @else
                        @if (isset($allmovies))
                            <tbody>

                                @foreach ($allmovies as $user)
                                <tr>
                                    <td>{{ $user['id'] }}</td>
                                    <td class="btn-edit">
                                        <div class="dropdown">
                                            <div class="select">
                                                <span class="selected">Options</span>
                                                <div class="caret"></div>
                                            </div>
                                            <ul class="menu">

                                                <li><a href="{{ route('edittvcreate', $user['id']) }}">Edit
                                                    TV</a></li>
                                                        <li><a href="{{ route('managerseason.create', $user['id']) }}">Manage
                                                            Seasons</a></li>
                                                <li><a href="{{ route('delettv', $user['id']) }}">Delete</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                    <td class="poster"><img src="{{ $user['poster'] }}" alt=""></td>
                                    <td class="mytitle">{{ $user['title'] }}</td>
                                    <td>{{ $user['story'] }}</td>
                                    <td class="warning">{{ $user['place'] }}</td>


                                </tr>
                                @endforeach



                            </tbody>
                        @endif

                </table>

                @endif



            </div>
            @if (isset($result))
            <div class="mynav">
                {{ $result->links('pagination::bootstrap-4') }}
            </div>
            @else
            <div class="mynav">
                {{ $allmovies->links('pagination::bootstrap-4') }}
            </div>
            @endif



        </main>


    </div>



@endsection
