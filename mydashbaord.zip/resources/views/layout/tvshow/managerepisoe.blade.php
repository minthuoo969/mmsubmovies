@extends('home')

@section('title', 'Manage Episodes')

@section('contant')


    <div class="create-movie">

        @if ($errors->any())
            <div class="col-12">
                @foreach ($errors->all() as $error)
                    <h4 class="textsucc">{{ $error }}</h4>
                @endforeach
            </div>

        @endif


        <form action="{{route('storevideo',$season['id'])}}" method="post">
            @csrf

            <div class="importdata">



                <div class="meddle">
                    <div class="container-movies-2">
                        <main>


                            <div class="all-movies">

                                <section class="movie-section">


                                    <div class="king-info">

                                        <div class="containertow2">
                                            <div class="Movie-Info">
                                                <h2>Add Videos ({{ $tv['title'] }}   Season {{$season['name']}})</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Label</b></h2>

                                                        <input type="text" name="lebel" class="record-tmdb_id"
                                                            value="{{ old('lebel') }}">

                                                </div>


                                                <div class="m-title">
                                                    <h3><b>Quality</b></h2>

                                                        <input type="text" name="quality" class="record-tmdb_id"
                                                            value="{{ old('quality') }}">

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Size</b></h2>

                                                        <input type="text" name="size" class="record-tmdb_id"
                                                            value="{{ old('size') }}">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Source</b></h2>


                                                        <select name="source">

                                                            @foreach (json_decode(
            '{
                                                                                "Youtube":"Youtube",
                                                                                "Mp4":"Mp4 From Url",
                                                                                "Mkv":"Mkv From Url",
                                                                                "M3u8":"M3u8 From Url",
                                                                                "Dash":"Dash From Url",
                                                                                "Embed":"Embed Url",
                                                                                "Dailymotion":"Dailymotion",
                                                                                "DoodStream":"DoodStream",
                                                                                "Dropbox":"Dropbox",
                                                                                "Facebook":"Facebook",
                                                                                "MixDrop":"MixDrop",
                                                                                "OKru":"OKru",
                                                                                "StreamSB":"StreamSB",
                                                                                "StreamTape":"StreamTape",
                                                                                "VK":"VK",
                                                                                "Vimeo":"Vimeo"
                                                                             }',
            true,
        ) as $optionKey => $optionValu)
                                                                <option value="{{ $optionKey }}">{{ $optionValu }}
                                                                </option>
                                                            @endforeach

                                                        </select>

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Url</b></h2>

                                                        <input type="text" name="url" class="record-tmdb_id"
                                                            value="{{ old('url') }}">

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Status</b></h2>


                                                        <select name="status">

                                                            @foreach (json_decode('{"Published":"Published","Unpublished":"Unpublished"}', true) as $optionKey => $optionValu)
                                                                <option value="{{ $optionKey }}">{{ $optionValu }}
                                                                </option>
                                                            @endforeach

                                                        </select>

                                                </div>
                                                <div class="addmoviebtn">

                                                    <button class="fetch-btn">Add Video</button>

                                                </div>



                                            </div>

                                        </div>


                                    </div>


                                    <div class="kingalvideo">
                                        <div class="record-header">
                                            <div class="add">
                                                <span>Page</span>
                                                <select name="" id="">
                                                    <option value="">ID</option>
                                                </select>
                                                {{-- <button>{{$textsearch}}</button> --}}
                                            </div>



                                        </div>

                                        @if (count($video) > 0)

                                            <table>

                                                <thead>
                                                    <tr>
                                                        <th>Option</th>
                                                        <th>Label</th>
                                                        <th>Source</th>
                                                        <th>Url</th>
                                                        <th>Status</th>
                                                        <th>Quality</th>
                                                        <th>Size</th>
                                                    </tr>
                                                </thead>
                                                <tbody>



                                                    @foreach ($video as $user)
                                                        <tr>

                                                            <td class="btn-edit">
                                                                <div class="dropdown">
                                                                    <div class="select">
                                                                        <span class="selected">Options</span>
                                                                        <div class="caret"></div>
                                                                    </div>
                                                                    <ul class="menu">
                                                                        <li><a
                                                                                href="{{ route('deleepisodeideo', $user['id']) }}">Delete</a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </td>
                                                            <td class="mytitle">{{ $user['lebel'] }}</td>
                                                            <td>{{ $user['source'] }}</td>
                                                            <td class="myurl">{{ $user['url'] }}</td>
                                                            <td class="warning">{{ $user['status'] }}</td>
                                                            <td class="mytitle">{{ $user['quality'] }}</td>
                                                            <td class="mytitle">{{ $user['size'] }}</td>

                                                        </tr>
                                                    @endforeach



                                                </tbody>

                                            </table>
                                        @else
                                            <h2 class="modatavideo">No Videos Added Yet</h2>


                                        @endif



                                    </div>


                                </section>



                            </div>



                        </main>


                    </div>
                </div>



            </div>







        </form>
    </div>








@endsection
