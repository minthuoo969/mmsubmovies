@extends('home')

@section('title', 'Season Manager')

@section('contant')



    <div class="container-movies">
        <main>
@if ($errors->any())
                <div class="col-12">
                    @foreach ($errors->all() as $error)
                        <h4 class="textsucc">{{ $error }}</h4>
                    @endforeach
                </div>

            @endif

            <div class="container-fluid mt-5 bg-white p-4 rounded shadow">
                <div class="d-flex justify-content-between">
                    <div>
                        <h1>{{ $tv['title'] }}</h1>
                    </div>
                    <div>
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end black">


                            <button type="button" class="btn btn-success" data-bs-toggle="modal"
                                data-bs-target="#exampleModal">Add Season</button>

                         <!-- <form id="tm" action="{{route('getSeasonsFromTMDB',$tv['tmdb_id'])}}" method="get">
                            @csrf
                            <div class="input-box button">
                             <button form="tm" class="fetch-btn">Bulk Seasons</button>
                            </div>
                          
                          </form>-->
                              

                        </div>

                    </div>

                </div>

                <table class="table ">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Options</th>
                            <th scope="col">Name</th>
                            <th scope="col">Episodes</th>
                            <th scope="col">status</th>
                        </tr>
                    </thead>


                    @if (isset($seasons))
                        <tbody>

                            @foreach ($seasons as $season)
                                <tr>
                                    <td>{{ $season['id'] }}</td>
                                    <td class="btn-edit">
                                        {{-- <div class="dropdown">
                                            <div class="select">
                                                <span class="selected">Options</span>
                                                <div class="caret"></div>
                                            </div>
                                            <ul class="menu">

                                                <li><a href="">Edit
                                            Season</a></li>
                                    <li><a href="">Manage
                                            Episodes</a></li>
                                    <li><a href="{{ route('deletseason', $season['id']) }}">Delete</a></li>
                                            </ul>
                                        </div> --}}
                                        <a href="{{ route('showepisodes', $season['id']) }}">
                                            <button type="button" class="btn">Manage Episodes</button>


                                            <a href="{{ route('deletseason', $season['id']) }}">
                                                <button type="button" class="btn">Delete</button></a>
                                    </td>
                                    <td class="mytitle">{{ $season['name'] }}</td>

                                    <?php

                                    $episdoecount = \App\Models\episodemodel::getepisodecount($tv['id'],$season['id']);
                                    ?>
                                    <td class="mytitle">{{ $episdoecount }}</td>
                                    <td class="warning">{{ $season['status'] }}</td>


                                </tr>
                            @endforeach



                        </tbody>
                    @endif

                </table>





            </div>




        </main>


    </div>
    @include('demo')


@endsection
