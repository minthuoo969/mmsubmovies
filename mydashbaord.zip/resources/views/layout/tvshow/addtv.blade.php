@extends('home')

@section('title', 'ADD TV')

@section('contant')


    <div class="create-movie">

        <div class="top">
            <h4 class="textaround">Import Contents From TMDB</h4>
            <div class="fetch">
                <form id="tm" action="{{route('gettvFromTMDB')}}" method="post">
                    @csrf
                    <input type="text"  name="tmdb" placeholder="Enter TMDB ID. Ex: 38846" id="tmdb"
                        value="{{ old('tmdb') }}" class="record-tmdb_id">



                    <div class="input-box button">
                        <button form="tm" class="fetch-btn">Fetch</button>
                    </div>

                </form>



            </div>
            <h3>Get IMDB ID from here : <a href="https://www.themoviedb.org"> TheMovieDB.org</a></h3>

            {{-- <h4 class="textsucc">Data <b>imported</b> successfully.</h4> --}}
            @if ($errors->any())
                <div class="col-12">
                    @foreach ($errors->all() as $error)
                        <h4 class="textsucc">{{ $error }}</h4>
                    @endforeach
                </div>

            @endif

            @if (isset($akhta))
            <div class="alert alert-danger">
                <h4 class="textsucc">{{ $akhta }}</h4>
            </div>
        @endif
        </div>
        <form action="{{route('Addtv.post')}}" method="post">
            @csrf
            <div class="importdata">

                @if (isset($data))

                <div class="meddle">
                    <div class="container-movies-2">
                        <main>


                            <div class="all-movies">

                                <section class="movie-section">


                                    <div class="king-info">

                                        <div class="containertow">
                                            <div class="Movie-Info">
                                                <h2>TV Info</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Title</b></h2>




                                                        <input type="text" name="title" class="record-tmdb_id"
                                                        @if (isset($data['name']))
                                                        value="{{
                                                           $data['name'] }}"

                                                    @endif value="{{
                                                            old('title') }}">

                                                </div>


                                                <div class="m-title">
                                                    <h3><b>Description</b></h2>



                                                        <textarea name="story" id="text-desc" rows="5" value="ddd">@if ($data['overview']) {{$data['overview']}} @endif</textarea><p class="counter" id="result"></p>

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Geners</b></h2>

                                                        <p>add a comma after each tag</p>
                                                        <input type="text" name="gener"


                                                       @if(count($data['genres']) > 0)



                                                       @foreach ($data['genres'] as $singleGenre)
                                                       value="{{ $singleGenre['name'] }}"
                                                       @endforeach




                                                       @endif



                                                            placeholder="action,comedy,horror.....">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Release Date</b></h2>


                                                        <input type="text" name="year"

                                                        value="{{ date('Y',strtotime($data['first_air_date'])) }}"
                                                            placeholder="add year : 2024..." class="record-date">

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Country</b></h2>


                                                        <input type="text" name="country" value="{{ old('country') }}"
                                                            placeholder="usa,canada,japon..." class="record-date">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Age</b></h2>


                                                        <input type="text" name="age" placeholder="+13,+14,+18....."
                                                            class="record-date" value="{{ old('age') }}">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>TMDB ID</b></h2>


                                                        <input type="text" name="tmdbid" placeholder="264633..."
                                                            class="record-date" value="{{$data['id']}}">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Status</b></h2>


                                                        <select name="status">

                                                            @foreach (json_decode('{"Published":"Published","Unpublished":"Unpublished"}', true) as $optionKey => $optionValu)
                                                                <option value="{{ $optionKey }}">{{ $optionValu }}
                                                                </option>
                                                            @endforeach

                                                        </select>

                                                </div>





                                            </div>
                                            <div class="Movie-Info-2">
                                                <h2>Additional Info</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Thumbnail</b></h2>

                                                        <div class="img-poster">
                                                            <img id="poster"
                                                                @if (isset($data['poster_path'])) src=" https://www.themoviedb.org/t/p/w600_and_h900_face{{ $data['poster_path'] }}"
                                                            @else
                                                            src=" https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ngl2FKBlU4fhbdsrtdom9LVLBXw.jpg " @endif
                                                                alt="">


                                                        </div>
                                                        <div class="fetch">

                                                            <input type="text" name="poster" id="posterlink"
                                                            @if (isset($data['poster_path'])) value=" https://www.themoviedb.org/t/p/w600_and_h900_face{{ $data['poster_path'] }}"
                                                            @endif

                                                                placeholder="Image URL (Best Fit = 500 x 750)"
                                                                class="record-poster">

                                                            <div class="input-box button">

                                                                <input id="setposter" class="fetch-btn" type="button"
                                                                    value="SET">

                                                            </div>
                                                        </div>
                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Poster</b></h2>

                                                        <div class="img-poster">
                                                            <img  class="cover" id="cover"
                                                                @if (isset($data['backdrop_path'])) src=" https://www.themoviedb.org/t/p/w600_and_h900_face{{ $data['backdrop_path'] }}"
                                                            @else
                                                            src=" https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ngl2FKBlU4fhbdsrtdom9LVLBXw.jpg " @endif
                                                                alt="">



                                                        </div>
                                                        <div class="fetch">

                                                            <input type="text" name="cover" id="coverlink"
                                                            @if (isset($data['backdrop_path'])) value=" https://www.themoviedb.org/t/p/w600_and_h900_face{{ $data['backdrop_path'] }}"
                                                            @endif

                                                                placeholder="Image URL (Best Fit = 2048 x 1152)"
                                                                class="record-poster">

                                                            <div class="input-box button">
                                                                <input id="setcover" class="fetch-btn" type="button"
                                                                    value="SET">

                                                            </div>

                                                        </div>
                                                </div>



                                            </div>
                                        </div>

                                    </div>




                                </section>



                            </div>



                        </main>


                    </div>
                </div>

                @else

                <div class="meddle">
                    <div class="container-movies-2">
                        <main>


                            <div class="all-movies">

                                <section class="movie-section">


                                    <div class="king-info">

                                        <div class="containertow">
                                            <div class="Movie-Info">
                                                <h2>TV Info</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Title</b></h2>




                                                        <input type="text" name="title" class="record-tmdb_id" value="{{ old('title') }}">

                                                </div>


                                                <div class="m-title">
                                                    <h3><b>Description</b></h2>



                                                        <textarea name="story" id="text-desc" rows="5" value="ddd">{{old('story')}}</textarea><p class="counter" id="result"></p>

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Geners</b></h2>

                                                        <p>add a comma after each tag</p>
                                                        <input type="text" name="gener"







                                                       value="{{ old('gener') }}"









                                                            placeholder="action,comedy,horror.....">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Release Date</b></h2>


                                                        <input type="text" name="year"

                                                        value="{{ old('year') }}"
                                                            placeholder="add year : 2024..." class="record-date">

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Country</b></h2>


                                                        <input type="text" name="country" value="{{ old('country') }}"
                                                            placeholder="usa,canada,japon..." class="record-date">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Age</b></h2>


                                                        <input type="text" name="age" placeholder="+13,+14,+18....."
                                                            class="record-date" value="{{ old('age') }}">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>TMDB ID</b></h2>


                                                        <input type="text" name="tmdbid" placeholder="264633..."
                                                            class="record-date" value="{{old('tmdbid')}}">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Status</b></h2>


                                                        <select name="status">

                                                            @foreach (json_decode('{"Published":"Published","Unpublished":"Unpublished"}', true) as $optionKey => $optionValu)
                                                                <option value="{{ $optionKey }}">{{ $optionValu }}
                                                                </option>
                                                            @endforeach

                                                        </select>

                                                </div>





                                            </div>
                                            <div class="Movie-Info-2">
                                                <h2>Additional Info</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Thumbnail</b></h2>

                                                        <div class="img-poster">
                                                            <img id="poster"

                                                            src=" https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ngl2FKBlU4fhbdsrtdom9LVLBXw.jpg "
                                                                alt="">


                                                        </div>
                                                        <div class="fetch">

                                                            <input type="text" name="poster" id="posterlink"
                                                                value="{{ old('poster') }}"
                                                                placeholder="Image URL (Best Fit = 500 x 750)"
                                                                class="record-poster">

                                                            <div class="input-box button">

                                                                <input id="setposter" class="fetch-btn" type="button"
                                                                    value="SET">

                                                            </div>
                                                        </div>
                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Poster</b></h2>

                                                        <div class="img-poster">
                                                            <img  class="cover" id="cover"

                                                            src=" https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ngl2FKBlU4fhbdsrtdom9LVLBXw.jpg "
                                                                alt="">



                                                        </div>
                                                        <div class="fetch">

                                                            <input type="text" name="cover" id="coverlink"
                                                                value="{{ old('cover') }}"
                                                                placeholder="Image URL (Best Fit = 2048 x 1152)"
                                                                class="record-poster">

                                                            <div class="input-box button">
                                                                <input id="setcover" class="fetch-btn" type="button"
                                                                    value="SET">

                                                            </div>

                                                        </div>
                                                </div>



                                            </div>
                                        </div>

                                    </div>




                                </section>



                            </div>



                        </main>


                    </div>
                </div>
                @endif

                <div class="addmoviebtn">

                    <button class="fetch-btn">Add TV</button>

                </div>
            </div>




        </form>
    </div>




    <script>
        const setposter = document.getElementById('setposter');
        var posterlink = document.getElementById('posterlink');
        var poster = document.getElementById('poster');

        const setcover = document.getElementById('setcover');
        var coverlink = document.getElementById('coverlink');
        var cover = document.getElementById('cover');



        setposter.addEventListener('click', () => {

            poster.src = posterlink.value;

        });


        setcover.addEventListener('click', () => {

            cover.src = coverlink.value;

        });
    </script>



@endsection
