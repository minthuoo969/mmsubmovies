@extends('home')

@section('title', 'EDIT MOVIE')

@section('contant')


    <div class="create-movie">

        @if ($errors->any())
        <div class="col-12">
            @foreach ($errors->all() as $error)
                <h4 class="textsucc">{{ $error }}</h4>
            @endforeach
        </div>

    @endif
        <form action="{{route('editmovie',$movie['id'])}}" method="post">
            @csrf
            @method('PUT')
            <div class="importdata">

                @if (isset($movie))

                <div class="meddle">
                    <div class="container-movies-2">
                        <main>


                            <div class="all-movies">

                                <section class="movie-section">


                                    <div class="king-info">

                                        <div class="containertow">
                                            <div class="Movie-Info">
                                                <h2>Movie Info</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Title</b></h2>




                                                        <input type="text" name="title" class="record-tmdb_id"
                                                        @if ($movie['title'] )
                                                        value="{{
                                                           $movie['title'] }}"

                                                    @endif value="{{
                                                            old('title') }}">

                                                </div>


                                                <div class="m-title">
                                                    <h3><b>Description</b></h2>



                                                        <textarea name="story" id="text-desc" rows="5" value="ddd">@if ($movie['story']) {{$movie['story']}} @endif</textarea><p class="counter" id="result"></p>

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Geners</b></h2>

                                                        <p>add a comma after each tag</p>
                                                        <input type="text" name="gener"


                                                       value="{{ $movie['gener'] }}"




                                                            placeholder="action,comedy,horror.....">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Release Date</b></h2>


                                                        <input type="text" name="year"

                                                        value="{{ date('Y',strtotime($movie['year'])) }}"
                                                            placeholder="add year : 2024..." class="record-date">

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Country</b></h2>


                                                        <input type="text" name="country" value="{{ old('country') }}"
                                                            placeholder="usa,canada,japon..." class="record-date">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Age</b></h2>


                                                        <input type="text" name="age" placeholder="+13,+14,+18....."
                                                            class="record-date" value="{{ old('age') }}">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>TMDB ID</b></h2>


                                                        <input type="text" name="tmdbid" placeholder="264633..."
                                                            class="record-date" value="{{$movie['tmdb_id']}}">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Status</b></h2>


                                                        <select name="status">

                                                            @foreach (json_decode('{"Published":"Published","Unpublished":"Unpublished"}', true) as $optionKey => $optionValu)
                                                                <option value="{{ $optionKey }}">{{ $optionValu }}
                                                                </option>
                                                            @endforeach

                                                        </select>

                                                </div>





                                            </div>
                                            <div class="Movie-Info-2">
                                                <h2>Additional Info</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Thumbnail</b></h2>

                                                        <div class="img-poster">
                                                            <img id="poster"
                                                                src="{{ $movie['poster'] }}" alt="">


                                                        </div>
                                                        <div class="fetch">

                                                            <input type="text" name="poster" id="posterlink"
                                                            @if (isset($movie['poster'])) value="{{ $movie['poster'] }}"
                                                            @endif

                                                                placeholder="Image URL (Best Fit = 500 x 750)"
                                                                class="record-poster">

                                                            <div class="input-box button">

                                                                <input id="setposter" class="fetch-btn" type="button"
                                                                    value="SET">

                                                            </div>
                                                        </div>
                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Poster</b></h2>

                                                        <div class="img-poster">
                                                            <img  class="cover" id="cover"
                                                                @if (isset($movie['cover'])) src=" {{ $movie['cover'] }}"
                                                            @else
                                                            src=" https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ngl2FKBlU4fhbdsrtdom9LVLBXw.jpg " @endif
                                                                alt="">



                                                        </div>
                                                        <div class="fetch">

                                                            <input type="text" name="cover" id="coverlink"
                                                            @if (isset($movie['cover'])) value="{{ $movie['cover'] }}"
                                                            @endif

                                                                placeholder="Image URL (Best Fit = 2048 x 1152)"
                                                                class="record-poster">

                                                            <div class="input-box button">
                                                                <input id="setcover" class="fetch-btn" type="button"
                                                                    value="SET">

                                                            </div>

                                                        </div>
                                                </div>



                                            </div>
                                        </div>

                                    </div>




                                </section>



                            </div>



                        </main>


                    </div>
                </div>

                @else

                <div class="meddle">
                    <div class="container-movies-2">
                        <main>


                            <div class="all-movies">

                                <section class="movie-section">


                                    <div class="king-info">

                                        <div class="containertow">
                                            <div class="Movie-Info">
                                                <h2>Movie Info</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Title</b></h2>




                                                        <input type="text" name="title" class="record-tmdb_id" value="{{ old('title') }}">

                                                </div>


                                                <div class="m-title">
                                                    <h3><b>Description</b></h2>



                                                        <textarea name="story" id="text-desc" rows="5" value="ddd">{{old('story')}}</textarea><p class="counter" id="result"></p>

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Geners</b></h2>

                                                        <p>add a comma after each tag</p>
                                                        <input type="text" name="gener"







                                                       value="{{ old('gener') }}"









                                                            placeholder="action,comedy,horror.....">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Release Date</b></h2>


                                                        <input type="text" name="year"

                                                        value="{{ old('year') }}"
                                                            placeholder="add year : 2024..." class="record-date">

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Country</b></h2>


                                                        <input type="text" name="country" value="{{ old('country') }}"
                                                            placeholder="usa,canada,japon..." class="record-date">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Age</b></h2>


                                                        <input type="text" name="age" placeholder="+13,+14,+18....."
                                                            class="record-date" value="{{ old('age') }}">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>TMDB ID</b></h2>


                                                        <input type="text" name="tmdbid" placeholder="264633..."
                                                            class="record-date" value="{{old('tmdbid')}}">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Status</b></h2>


                                                        <select name="status">

                                                            @foreach (json_decode('{"Published":"Published","Unpublished":"Unpublished"}', true) as $optionKey => $optionValu)
                                                                <option value="{{ $optionKey }}">{{ $optionValu }}
                                                                </option>
                                                            @endforeach

                                                        </select>

                                                </div>





                                            </div>
                                            <div class="Movie-Info-2">
                                                <h2>Additional Info</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Thumbnail</b></h2>

                                                        <div class="img-poster">
                                                            <img id="poster"

                                                            src=" https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ngl2FKBlU4fhbdsrtdom9LVLBXw.jpg "
                                                                alt="">


                                                        </div>
                                                        <div class="fetch">

                                                            <input type="text" name="poster" id="posterlink"
                                                                value="{{ old('poster') }}"
                                                                placeholder="Image URL (Best Fit = 500 x 750)"
                                                                class="record-poster">

                                                            <div class="input-box button">

                                                                <input id="setposter" class="fetch-btn" type="button"
                                                                    value="SET">

                                                            </div>
                                                        </div>
                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Poster</b></h2>

                                                        <div class="img-poster">
                                                            <img  class="cover" id="cover"

                                                            src=" https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ngl2FKBlU4fhbdsrtdom9LVLBXw.jpg "
                                                                alt="">



                                                        </div>
                                                        <div class="fetch">

                                                            <input type="text" name="cover" id="coverlink"
                                                                value="{{ old('cover') }}"
                                                                placeholder="Image URL (Best Fit = 2048 x 1152)"
                                                                class="record-poster">

                                                            <div class="input-box button">
                                                                <input id="setcover" class="fetch-btn" type="button"
                                                                    value="SET">

                                                            </div>

                                                        </div>
                                                </div>



                                            </div>
                                        </div>

                                    </div>




                                </section>



                            </div>



                        </main>


                    </div>
                </div>
                @endif

                <div class="addmoviebtn">

                    <button class="fetch-btn">Update Movie</button>

                </div>
            </div>




        </form>
    </div>




    <script>
        const setposter = document.getElementById('setposter');
        var posterlink = document.getElementById('posterlink');
        var poster = document.getElementById('poster');

        const setcover = document.getElementById('setcover');
        var coverlink = document.getElementById('coverlink');
        var cover = document.getElementById('cover');



        setposter.addEventListener('click', () => {

            poster.src = posterlink.value;

        });


        setcover.addEventListener('click', () => {

            cover.src = coverlink.value;

        });
    </script>



@endsection
