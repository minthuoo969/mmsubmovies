@extends('home')

@section('title', 'DASHBOARD')

@section('contant')

    <div class="container">
        <main>


            <div class="insights">

                <div class="sales">



                    <div class="middle">
                        <div class="left">

                            <h3>TOTAL MOVIE</h3>
                            <h1>{{ $moviecount }}</h1>

                        </div>

                        <span class="material-symbols-sharp">movie</span>

                    </div>
                </div>

                <!--- End OF MOVIES----->
                <div class="income">



                    <div class="middle">
                        <div class="left">

                            <h3>TOTAL SERIES</h3>
                            <h1>{{ $tvcount }}</h1>

                        </div>

                        <span class="material-symbols-sharp">tv</span>

                    </div>
                </div>

                <!--- End OF SERIES----->
                <div class="expencecs">



                    <div class="middle">
                        <div class="left">

                            <h3>TOTAL USERS</h3>
                            <h1>{{ $usercount }}</h1>

                        </div>
                        <span class="material-symbols-sharp">person</span>

                    </div>
                </div>

                <!--- End OF users----->
                <div class="expencecs">



                    <div class="middle">
                        <div class="left">

                            <h3>TOTAL VIDEOS</h3>
                            <h1>{{ $videocount }}</h1>

                        </div>
                        <span class="material-symbols-sharp">all_inclusive</span>

                    </div>
                </div>

                <!--- End OF PRIMUME----->

            </div>

            <!--- End OF insights----->


            <div class="recent-orders">
                <h2>Most viewed Movies Today</h2>
                <table class="table mt-2">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>View</th>
                            <th>TMDB ID</th>

                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($movievisitedtoday as $user)
                            <tr>
                                <td>{{ $user['id'] }}</td>
                                <td>{{ $user['title'] }}</td>
                                <td>{{ $user['visit_count_total'] }}</td>

                                <td>{{ $user['tmdb_id'] }}</td>

                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <div class="recent-orders">
                <h2>Most viewed TV SHOWS Today</h2>
                <table class="table mt-2">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>View</th>
                            <th>TMDB ID</th>

                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($tvshowsvisitedtoday as $user)
                            <tr>
                                <td>{{ $user['id'] }}</td>
                                <td>{{ $user['title'] }}</td>
                                <td>{{ $user['visit_count_total'] }}</td>
                                <td>{{ $user['tmdb_id'] }}</td>

                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="containertow">
                <div class="recent-orders">
                    <h2>Most viewed Tv Shows</h2>
                    <table class="table mt-2">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>View</th>
                                <th>TMDB ID</th>

                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($mosttvshowsvisited as $user)
                                <tr>
                                    <td>{{ $user['id'] }}</td>
                                    <td>{{ $user['title'] }}</td>
                                    <td>{{ $user['visit_count_total'] }}</td>
                                    <td>{{ $user['tmdb_id'] }}</td>

                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="recent-orders">
                    <h2>Most viewed Movies</h2>
                    <table class="table mt-2">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>View</th>
                                <th>TMDB ID</th>

                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($mostmovievisted as $user)
                                <tr>
                                    <td>{{ $user['id'] }}</td>
                                    <td>{{ $user['title'] }}</td>
                                    <td>{{ $user['visit_count_total'] }}</td>
                                    <td>{{ $user['tmdb_id'] }}</td>

                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

            </div>

            <div class="recent-orders">
                <h2>New Users</h2>
                <table class="table mt-2">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Full Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Subscription</th>
                        </tr>
                    </thead>



                    <tbody>
                        @foreach ($allusers as $user)


                            <tr>
                                <td>{{ $user['id'] }}</td>

                                <td class="mytitle">{{ $user['name'] }}</td>
                                <td class="mytitle">{{ $user['email'] }}</td>
                                <td class="warning">{{ $user['Subscription'] }}</td>


                            </tr>

                            @endforeach


                    </tbody>


                </table>
            </div>
        </main>


    </div>




@endsection
