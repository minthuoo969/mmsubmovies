@extends('home')

@section('title', 'GENERS')

@section('contant')



    <div class="container-movies">
        <main>


            <div class="all-movies">

                <section class="movie-section">
                    <div class="sales-analytics">
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end black">

                            <div class="input-box button">
                                <button form="tm" class="fetch-btn" data-bs-toggle="modal" data-bs-target="#addGeners">Add
                                    Geners</button>
                            </div>


                        </div>



                </section>




            </div>

            <div class="container-fluid mt-5 bg-white p-4 rounded shadow">
                <div class="d-flex justify-content-between">
                    <div>
                        <h1>All GENERS</h1>
                        <form action="" method="GET">
                            @csrf
                            <div class="browse">

                                <input type="search" name="query" placeholder="search" class="record-search">

                            </div>
                        </form>
                    </div>
                    <div>
                        <span class="fs-6 badge rounded-pill text-bg-dark">
                            Total GENERS : {{ count($geners) }}
                        </span>
                    </div>

                </div>

                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Options</th>
                            <th scope="col">Image</th>
                            <th scope="col">Name</th>
                            <th scope="col">Status</th>
                        </tr>
                    </thead>

                    @if (isset($result))
                        <tbody>
                            @foreach ($result as $user)
                                <tr>
                                    <td>{{ $user['id'] }}</td>
                                    <td class="btn-edit">
                                        <a href="{{ route('deletgener', $user['id']) }}">
                                        <button class="btn">Delete</button>
                                        </a>
                                    </td>
                                    <td class="iconm"><img src="{{ $user['icon'] }}" alt=""></td>
                                    <td class="mytitle">{{ $user['name'] }}</td>
                                    <td class="warning">{{ $user['status'] }}</td>


                                </tr>
                            @endforeach

                        </tbody>
                    @else
                        @if (isset($geners))
                            <tbody>

                                @foreach ($geners as $user)
                                    <tr>
                                        <td>{{ $user['id'] }}</td>
                                        <td class="btn-edit">
                                            <a href="{{ route('deletgener', $user['id']) }}">
                                            <button class="btn">Delete</button>
                                            </a>
                                        </td>
                                        <td class="iconm"><img src="{{ $user['icon'] }}" alt=""></td>
                                        <td class="mytitle">{{ $user['name'] }}</td>
                                        <td class="warning">{{ $user['status'] }}</td>


                                    </tr>
                                @endforeach



                            </tbody>
                        @endif

                </table>

                @endif



            </div>
            @if (isset($result))
                <div class="mynav">
                    {{ $result->links('pagination::bootstrap-4') }}
                </div>
            @else
                <div class="mynav">
                    {{ $geners->links('pagination::bootstrap-4') }}
                </div>
            @endif



        </main>


    </div>




    <div class="modal fade" id="addGeners" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">

                    <h1 class="modal-title fs-5" id="exampleModalLabel">Add Geners</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

                </div>

                <div class="modal-body">
                    @if ($errors->any())
                        <div class="col-12">
                            @foreach ($errors->all() as $error)
                                <h4 class="textsucc">{{ $error }}</h4>
                            @endforeach
                        </div>
                    @endif
                    <form method="post" action="{{ route('addgeners') }}">
                        @csrf
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">Name</label>
                            <input type="text" class="form-control" id="recipient-name" name="name">
                        </div>
                        <div class="mb-3">
                            <label for="order" class="col-form-label">Image</label>
                            <input type="text" class="form-control" id="recipient-name" name="icon">
                        </div>
                        <div class="mb-3">
                            <select name="status">

                                @foreach (json_decode('{"Published":"Published","Unpublished":"Unpublished"}', true) as $optionKey => $optionValu)
                                    <option class="form-control" value="{{ $optionKey }}">{{ $optionValu }}
                                    </option>
                                @endforeach

                            </select>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Add Gener</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>






@endsection
