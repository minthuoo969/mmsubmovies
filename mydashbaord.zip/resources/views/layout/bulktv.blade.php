@extends('home')

@section('title','BULK TV SHOWS')

@section('contant')
<div class="home-bulk">


    @if ($errors->any())
    <div class="col-12">
        @foreach ($errors->all() as $error)
            <h4 class="textsucc">{{ $error }}</h4>
        @endforeach
    </div>

@endif

    <form action="{{route('savetvshowsbulk')}}" method="post">
        @csrf

        <div class="Movie-bulk">
            <h2>BULK TV SHOWS : ADD A LOT OF TV SHOWS WITH SINGLE CLICK</h2>
            <hr>


            <div class="m-title">
                <h3><b>TV SHOWS's TMDB IDs</b></h2>

                    <textarea name="movies" placeholder="Add , After each ID like : 264866,667896,6678748,.."  id="text-desc" rows="5" >{{old('movies')}}</textarea>

            </div>


            <div class="m-title">
                <h3><b>Status</b></h2>


                    <select name="status">

                        @foreach (json_decode('{"Published":"Published","Unpublished":"Unpublished"}', true) as $optionKey => $optionValu)
                            <option value="{{ $optionKey }}">{{ $optionValu }}
                            </option>
                        @endforeach

                    </select>

            </div>



            <div class="addmoviebtn">

                <button class="fetch-btn">Add TV Show</button>

            </div>

        </div>




    </form>
  </div>

@endsection
