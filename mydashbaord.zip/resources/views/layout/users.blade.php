@extends('home')

@section('title', 'USERS')

@section('contant')



    <div class="container-movies">
        <main>


            <div class="all-movies">

                <section class="movie-section">
                    <div class="sales-analytics">
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end black">

                            <div class="input-box button">
                                <button form="tm" class="fetch-btn" data-bs-toggle="modal" data-bs-target="#addGeners">Add
                                    User</button>
                            </div>


                        </div>



                </section>




            </div>

            <div class="container-fluid mt-5 bg-white p-4 rounded shadow">
                <div class="d-flex justify-content-between">
                    <div>
                        <h1>All USERS</h1>
                        <form action="" method="GET">
                            @csrf
                            <div class="browse">

                                <input type="search" name="query" placeholder="search" class="record-search">

                            </div>
                        </form>
                    </div>
                    <div>
                        <span class="fs-6 badge rounded-pill text-bg-dark">
                            Total USERS : {{ count($users) }}
                        </span>
                    </div>

                </div>

                <table class="table mt-5">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Full Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Subscription</th>
                            <th scope="col">Options</th>
                        </tr>
                    </thead>

                    @if (isset($result))
                        <tbody>
                            @foreach ($result as $user)
                                <tr>
                                    <td>{{ $user['id'] }}</td>

                                    <td class="mytitle">{{ $user['name'] }}</td>
                                    <td class="mytitle">{{ $user['email'] }}</td>
                                    <td class="warning">{{ $user['Subscription'] }}</td>
                                    <td class="btn-edit">
                                        <a href="{{ route('DeletUser', $user['id']) }}">
                                        <button class="btn">Delete</button>
                                        </a>

                                    </td>


                                </tr>
                            @endforeach

                        </tbody>
                    @else
                        @if (isset($users))
                            <tbody>

                                @foreach ($users as $user)
                                    <tr>
                                        <td>{{ $user['id'] }}</td>

                                    <td class="mytitle">{{ $user['name'] }}</td>
                                    <td class="mytitle">{{ $user['email'] }}</td>
                                    <td class="warning">{{ $user['Subscription'] }}</td>

                                    <td class="btn-edit">
                                        <a href="{{ route('DeletUser', $user['id']) }}">
                                        <button class="btn">Delete</button>
                                        </a>

                                    </td>
                                    </tr>
                                @endforeach



                            </tbody>
                        @endif

                </table>

                @endif



            </div>
            @if (isset($result))
                <div class="mynav">
                    {{ $result->links('pagination::bootstrap-4') }}
                </div>
            @else
                <div class="mynav">
                    {{ $users->links('pagination::bootstrap-4') }}
                </div>
            @endif



        </main>


    </div>




    <div class="modal fade" id="addGeners" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">

                    <h1 class="modal-title fs-5" id="exampleModalLabel">Add User</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

                </div>

                <div class="modal-body">
                    @if ($errors->any())
                        <div class="col-12">
                            @foreach ($errors->all() as $error)
                                <h4 class="textsucc">{{ $error }}</h4>
                            @endforeach
                        </div>
                    @endif
                    <form method="post" action="{{ route('AddUser') }}">
                        @csrf
                        <div class="mb-3">
                            <label for="Name" class="col-form-label">Name</label>
                            <input type="text" class="form-control" id="Name" name="name">
                        </div>
                        <div class="mb-3">
                            <label for="Email" class="col-form-label">Email</label>
                            <input type="text" class="form-control" id="Email" name="email">
                        </div>
                        <div class="mb-3">
                            <label for="Password" class="col-form-label">Password</label>
                            <input type="password" class="form-control" id="Password" name="password">
                        </div>
                        <div class="mb-3">
                            <label for="Confirm" class="col-form-label">Confirm Password</label>
                            <input type="password" class="form-control" id="Confirm" >
                        </div>
                        <div  class="btn-edit">
                            <select name="Subscription">

                                @foreach (json_decode('{"Free":"Free","Premium":"Premium"}', true) as $optionKey => $optionValu)
                                    <option class="form-control" value="{{ $optionKey }}">{{ $optionValu }}
                                    </option>
                                @endforeach

                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="profil" class="col-form-label">Profil Image</label>
                            <input type="text" class="form-control" id="profil" name="profil" >
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Add User</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>






@endsection
