@extends('home')

@section('title', 'SKIP GOOGLE PLAY')

@section('contant')
    <div class="home-content">



        <div class="insideskip">


            @if ($errors->any())
                <div class="col-12">
                    @foreach ($errors->all() as $error)
                        <h4 class="textsucc">{{ $error }}</h4>
                    @endforeach
                </div>

            @endif

            <form method="post" action="{{ route('saveinfo') }}">
                @csrf

                @if (isset($data))
                    <div class="mb-3">
                        <label for="recipient-name" class="col-form-label">Text</label>
                       
                        <textarea name="text" class="form-control" id="recipient-name" rows="5" value="{{ $data['text'] }}">{{ $data['text'] }}</textarea>

                    </div>
                    <div class="mb-3">
                        <label for="ver-name" class="col-form-label">Version</label>
                        <input type="number" value="{{ $data['version'] }}" class="form-control" id="ver-name"
                            name="version">
                    </div>
                    <div class="mb-3">
                        <label for="order" class="col-form-label">Show Empty Screen On Start ?</label>

                        <select name="status" >

                            @foreach (json_decode('{"true":"true","false":"false"}') as $optionKey => $optionValu)
                                <option class="form-control" value="{{ $optionKey }}">{{ $optionValu  }}
                                </option>
                            @endforeach

                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                @else
                    <div class="mb-3">
                        <label for="recipient-name" class="col-form-label">Text</label>
                        
                         <textarea name="text" class="form-control" id="recipient-name" rows="5" ></textarea>

                    </div>
                    <div class="mb-3">
                        <label for="ver-name" class="col-form-label">Version</label>
                        <input type="number"  class="form-control" id="ver-name"
                            name="version">
                    </div>
                    <div class="mb-3">
                        <label for="order" class="col-form-label">Show Empty Screen On Start ?</label>

                        <select name="status" >

                            @foreach (json_decode('{"true":"true","false":"false"}', true) as $optionKey => $optionValu)
                                <option class="form-control" value="{{ $optionKey }}">{{ $optionValu }}
                                </option>
                            @endforeach

                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>

                @endif
            </form>
        </div>


    </div>

@endsection
