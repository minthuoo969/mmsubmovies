<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>ANASS</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />

    <!-- Styles -->
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,600&display=swap');

        /*------------ ROOT VARAIBLES ---------*/

        :root {
            --color-primary: #00c3f4;
            --color-primary-variant: #0062f4;
            --color-gradient: linear-gradient(var(--color-primary), var(--color-primary-variant));
            --container-width-lg: 80%;
            --container-width-mg: 92%;

            --color-primary: #7380ec;
            --color-danger: #ff7782;
            --color-success: #41f1b6;
            --color-warning: #ffbb55;
            --color-white: #fff;
            --color-info-dark: #7d8da1;
            --color-info-light: #dce1eb;
            --color-dark: #363949;
            --color-light: rgba(132, 139, 200, 0.18);
            --color-primary-variant: #111e88;
            --color-dark-variant: #677483;
            --color-background: #f6f6f9;

            --card-border-radius: 2rem;
            --border-radius-1: 0.4rem;
            --border-radius-2: 0.8rem;
            --border-radius-3: 1.2rem;

            --card-padding: 1.8rem;
            --padding-1: 1.2rem;

            --box-shadow: 0 2rem 3rem var(--color-light);
        }


        .dark-theme-variables {
            --color-background: #181a1e;
            --color-white: #202528;
            --color-dark: #edeffd;
            --color-dark-variant: #a3bdcc;
            --color-light: rgba(0, 0, 0, 0.5);
            --box-shadow: 0 2rem 3rem var(--color-light);
        }


        *,
        *::after,
        *::before {
            margin: 0;
            padding: 0;
            text-decoration: none;
            list-style: none;
            box-sizing: border-box;
            font-family: poppins, sans-serif;

        }

        body {
            height: 100vh;
            background: var(--color-background);

        }

        .danger {
            font-size: 2rem;
            color: var(--color-primary);
        }

        nav {
            background: var(--color-white);
            width: 100vw;
            height: 4rem;
            display: grid;
            place-items: center;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 2;
        }

        .nav_container {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;

        }



        .nav_menu {
            width: var(--container-width-lg);
            height: 100%;
            display: flex;
            align-items: center;
        }

        .nav_menu .top {
            width: var(--container-width-lg);
            height: 100%;
            display: flex;
            align-items: center;

        }

        .nav_menu .top .menu {
            cursor: pointer;
            color: var(--color-dark-variant)
        }

        .nav .nav_toggle-btn {
            display: none;
        }


        .nav_logo {
            width: 35%;
            display: grid;
            place-items: center;

        }


        .nav_logo h3 {
            font-size: 2rem;
            color: var(--color-dark);
            transition: color 400ms ease;

        }

        .nav_logo h3:hover {
            color: var(--color-primary-variant);
        }

        .nav_links {
            display: flex;
            align-items: center;
            gap: 4.5rem;
            height: 100%;
        }

        .nav_links li {
            height: 100%;
        }

        .nav_links li a {
            color: black;
            font-weight: 500;
            height: 100%;
            display: flex;
            align-items: center;
            transition: color 400ms ease;
        }

        .nav_links li a:hover {
            color: var(--color-primary-variant);
        }

        section {
            height: 100%;
            display: flex;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            display: grid;
            width: 96%;
            margin: 0 auto;
            gap: 1.8rem;
            grid-template-columns: 15rem auto;
        }




        a {
            color: var(--color-dark);
        }

        img {
            display: block;
            width: 100%;
        }

        h1 {
            font-weight: 800;
            font-size: 1.8rem;
            color: var(--color-dark);
        }

        h2 {
            font-size: 1.4rem;
        }

        h3 {
            font-size: 0.87rem;
        }

        h4 {
            font-size: 0.8rem;
        }

        h4 {
            font-size: 0.77rem;
        }

        small {
            font-size: 0.75rem;
        }

        .profile-photo {
            width: 2.8rem;
            height: 2.8rem;

            border-radius: 50%;
            overflow: hidden;
        }

        .text-muted {
            color: var(--color-info-dark);
        }

        p {
            color: var(--color-dark-variant);
        }

        b {
            color: var(--color-dark);
        }

        .primry {
            color: var(--color-primary);
        }

        .success {
            color: var(--color-success);
        }

        .warning {
            color: var(--color-warning);
        }


        /*------------ Side BAr ---------*/


        aside {
            height: 100vh;
        }

        aside .top {
            display: flex;
            justify-content: center;
            margin-top: 4rem;
        }

        aside .top .logo h2 {
            font-size: 3rem;

        }


        aside .close {
            display: block;
        }


        aside .sidebar {
            display: flex;
            flex-direction: column;
            height: 86vh;
            position: relative;
            top: 2rem;
        }

        aside h3 {
            font-weight: 500;
        }

        aside .sidebar a {
            display: flex;
            color: var(--color-info-dark);
            margin-left: 2rem;
            gap: 1rem;
            align-items: center;
            position: relative;
            height: 3.7rem;
            transition: all 300ms ease;
        }

        aside .sidebar a span {
            font-size: 1.6rem;
            transition: all 300ms ease;
        }

        aside .sidebar a:last-child {
            position: absolute;
            bottom: 2rem;
            width: 100%;
        }

        aside .sidebar a.active {
            background: var(--color-light);
            color: var(--color-primary);
            margin-left: 0;
        }

        aside .sidebar a.active::before {
            content: '';
            width: 6px;
            height: 100%;
            background: var(--color-primary);
        }

        aside .sidebar a.active span {
            color: var(--color-primary);
            margin-left: calc(1rem - 3px);
        }

        aside .sidebar a:hover {
            color: var(--color-primary);
        }

        aside .sidebar a:hover span {
            margin-left: 1rem;
        }

        /*------------ MAIN ---------*/


        main {
            margin-top: 1.4rem;

        }

        main .insights {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1rem;
        }

        main .insights>div {
            background: var(--color-white);
            padding: var(--card-padding);
            border-radius: var(--card-border-radius);
            margin-top: 1rem;
            box-shadow: var(--box-shadow);
            transition: all 300ms ease;
        }

        main .insights>div:hover {
            box-shadow: none;
        }

        main .insights>div span {
            background: var(--color-primary);
            padding: 0.5rem;
            border-radius: 50%;
            color: var(--color-white);
            font-size: 2rem;
        }

        main .insights>div.expencecs span {
            background: var(--color-danger);
        }


        main .insights>div.income span {
            background: var(--color-success);
        }

        main .insights>div .middle {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        main .insights h3 {
            margin: 1rem 0 0.6rem;
            font-size: 1rem;
            color: var(--color-dark);
        }

        main .insights .progress {
            position: relative;
            width: 92px;
            height: 92px;
            border-radius: 50%;
        }

        main .insights svg {
            width: 7rem;
            height: 7rem;

        }

        main .insights svg circle {
            fill: none;
            stroke: var(--color-primary);
            stroke-width: 14;
            stroke-linecap: round;
            transform: translate(5px, 5px);
            stroke-dasharray: 110;
            stroke-dashoffset: 92;
        }

        main .insights .sales svg circle {
            stroke-dasharray: 90;
            stroke-dashoffset: -30;
        }

        main .insights .expenses svg circle {
            stroke-dasharray: 80;
            stroke-dashoffset: 20;
        }

        main .insights .income svg circle {
            stroke-dasharray: 110;
            stroke-dashoffset: 35;
        }


        main .insights .progress .number {
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
        }


        main .insights small {
            margin-top: 1.6rem;
            display: block;

        }


        /**** ========== recent-orders =========*****/


        main .recent-orders {
            margin-top: 2rem;
        }

        main .recent-orders h2 {
            margin-bottom: 0.8rem;
            color: var(--color-dark);
        }


        main .recent-orders table {
            background: var(--color-white);
            width: 100%;
            border-radius: 1rem;
            padding: var(--card-padding);
            text-align: center;
            box-shadow: var(--box-shadow);
            transition: all 300ms ease;
        }

        main .recent-orders table:hover {
            box-shadow: none;
        }

        main table thead th {
            color: var(--color-dark);
        }

        main table tbody td {
            height: 2.8rem;
            border-bottom: 1px solid var(--color-light);
            color: var(--color-dark-variant);
        }

        main table tbody tr:last-child td {
            border: none;
        }

        main .recent-orders a {
            text-align: center;
            display: block;
            margin: 1rem auto;
            color: var(--color-primary);
        }

        .nav_container .nav_left {

            width: 30%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: space-evenly;

        }

        .nav_container .nav_left .profile {
            display: flex;
            text-align: right;
            gap: 2rem;

        }

        .nav_container .nav_left .profile .info {
            width: 30%;
        }

        .nav_container .nav_left .profile .info p {

            text-align: center;
        }

        .nav_container .nav_left .theme-toggler {
            background: var(--color-light);
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 1.6rem;
            width: 4.2rem;
            cursor: pointer;
            border-radius: var(--border-radius-1);
        }

        .nav_container .nav_left .theme-toggler span {
            font-size: 1.2rem;
            width: 50%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }



        .nav_container .nav_left .theme-toggler span.active {
            background: var(--color-primary);
            color: white;
            border-radius: var(--border-radius-1);
        }
    </style>
</head>


<body>



    <nav>

        <div class="nav_container">
            <div class="nav_menu">
                <a href="#" class="nav_logo">
                    <h3><span class="danger">J</span>SERIES</h2>

                </a>
                <div class="top">
                    <div class="menu" id="menu-btn">
                        <span class="material-symbols-sharp">menu</span>
                    </div>
                </div>
            </div>

            <div class="nav_left">
                <div class="theme-toggler">
                    <span class="material-symbols-sharp active">light_mode</span>
                    <span class="material-symbols-sharp">dark_mode</span>
                </div>
                <div class="profile">
                    <div class="info">
                        <p>Hey, <b>Admin</b></p>
                    </div>
                    <div class="profile-photo">
                        <img src="https://i.pinimg.com/564x/0d/57/7b/0d577bb961dd8b968198ee37ba9bb6f6.jpg">
                    </div>
                </div>
            </div>

        </div>

    </nav>


    <div class="container">
        <aside>

            <div class="top">
                <div class="logo">


                </div>
                <div class="close" id="clode-btn">
                </div>
            </div>


            <div class="sidebar">
                <a href="#">
                    <span class="material-symbols-sharp">dashboard </span>
                    <h3>Dashboard</h3>
                </a>
                <a href="#" class="active">
                    <span class="material-symbols-sharp">movie </span>
                    <h3>Movies</h3>
                </a>
                <a href="#">
                    <span class="material-symbols-sharp">tv </span>
                    <h3>Tv Shows</h3>
                </a>
                <a href="#">
                    <span class="material-symbols-sharp">person</span>
                    <h3>Users</h3>
                </a>
                </a>
                <a href="#">
                    <span class="material-symbols-sharp">notifications</span>
                    <h3>Notification</h3>
                </a>
                <a href="#">
                    <span class="material-symbols-sharp">dashboard_customize</span>
                    <h3>Geners</h3>
                </a>
                <a href="#">
                    <span class="material-symbols-sharp">all_inclusive</span>
                    <h3>Subscriptiona</h3>
                </a>
                <a href="#">
                    <span class="material-symbols-sharp">settings</span>
                    <h3>Settings</h3>
                </a>
            </div>
        </aside>

        <!-------- END OF ASIDE -------->

        <main>
            <div class="topbar">
                <h1>Dashboard</h1>

            </div>

            <div class="insights">

                <div class="sales">



                    <div class="middle">
                        <div class="left">

                            <h3>TOTAL MOVIE</h3>
                            <h1>2534</h1>

                        </div>

                        <span class="material-symbols-sharp">movie</span>

                    </div>
                    <small class="text-muted">Since last month</small>
                </div>

                <!--- End OF MOVIES----->
                <div class="income">



                    <div class="middle">
                        <div class="left">

                            <h3>TOTAL SERIES</h3>
                            <h1>352</h1>

                        </div>

                        <span class="material-symbols-sharp">tv</span>

                    </div>
                    <small class="text-muted">Since last month</small>
                </div>

                <!--- End OF SERIES----->
                <div class="expencecs">



                    <div class="middle">
                        <div class="left">

                            <h3>TOTAL USERS</h3>
                            <h1>3843</h1>

                        </div>
                        <span class="material-symbols-sharp">person</span>

                    </div>
                    <small class="text-muted">Since last month</small>
                </div>

                <!--- End OF users----->
                <div class="expencecs">



                    <div class="middle">
                        <div class="left">

                            <h3>TOTAL PRIMUME</h3>
                            <h1>32</h1>

                        </div>
                        <span class="material-symbols-sharp">all_inclusive</span>

                    </div>
                    <small class="text-muted">Since last month</small>
                </div>

                <!--- End OF PRIMUME----->

            </div>

            <!--- End OF insights----->


            <div class="recent-orders">
                <h2>Most viewed Today </h2>
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>View</th>
                            <th>Type</th>
                            <th>Edit</th>

                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>The 100</td>
                            <td>665233</td>
                            <td>movie</td>
                            <td class="warning">pending</td>

                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Avatar: The Way of Water</td>
                            <td>665233</td>
                            <td>movie</td>
                            <td class="warning">pending</td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Black Panther</td>
                            <td>665233</td>
                            <td>movie</td>
                            <td class="warning">pending</td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>Sick</td>
                            <td>665233</td>
                            <td>movie</td>
                            <td class="warning">pending</td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td>Pokémon Detective Pikachu</td>
                            <td>665233</td>
                            <td>movie</td>
                            <td class="warning">pending</td>
                        </tr>
                        <tr>
                            <td>6</td>
                            <td>Venom</td>
                            <td>665233</td>
                            <td>movie</td>
                            <td class="warning">pending</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </main>


    </div>

    <script>
        const sideMenu = document.querySelector("aside");
        const menuBtn = document.querySelector("#menu-btn");
        const closeBtn = document.querySelector("#clode-btn");
        const themeToggler = document.querySelector(".theme-toggler");
        const container = document.querySelector(".container");
        var navToggled = false;



        function toggleNav() {
            if (navToggled) {
                openNav();
                navToggled = false;
            } else {
                closeNav();
                navToggled = true;
            }
        }

        function openNav() {
            sideMenu.style.display = 'block'
        }

        function closeNav() {
            sideMenu.style.display = 'none'


        }


        menuBtn.addEventListener('click', () => {
            toggleNav();
        })




        themeToggler.addEventListener('click', () => {
            document.body.classList.toggle('dark-theme-variables');
            themeToggler.querySelector('span:nth-child(1)').classList.toggle('active');
            themeToggler.querySelector('span:nth-child(2)').classList.toggle('active');

        })
    </script>

</body>

</html>
