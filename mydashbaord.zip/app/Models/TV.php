<?php

namespace App\Models;

use Coderflex\Laravisit\Concerns\CanVisit;
use Coderflex\Laravisit\Concerns\HasVisits;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TV extends Model implements CanVisit
{
    use HasFactory;
    use HasVisits;

    protected $table = "tv";

    protected $fillable = ['title','poster','year','place','gener','country','age','cover','story','tmdb_id'];


    public function seasons(){
        return $this->hasMany(SeasonModel::class);
    }
}
