<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class episodemodel extends Model
{
    use HasFactory;


    protected $table = "episodes";

    protected $fillable = ['lebel','tv_id','season_id','quality','size','source','url','status','type'];


    public static function getepisodecount($tv_id, $season_id) {
       return episodemodel::where(['tv_id' => $tv_id, 'season_id' => $season_id ])->count();
    }

}
