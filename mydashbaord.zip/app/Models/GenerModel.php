<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GenerModel extends Model
{
    use HasFactory;


    protected $table = "geners";


    protected $fillable = ['name','icon','status'];
}
