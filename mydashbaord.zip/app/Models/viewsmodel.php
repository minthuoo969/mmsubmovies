<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class viewsmodel extends Model
{
    use HasFactory;

    protected $table = "views";

    protected $fillable = ['title','views','type','tmdb_id','movie_id'];
}
