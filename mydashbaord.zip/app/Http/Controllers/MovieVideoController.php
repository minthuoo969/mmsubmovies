<?php

namespace App\Http\Controllers;

use App\Http\Requests\VideoMovieRequest;
use App\Models\Movie;
use App\Models\VideoMovieModel;
use Illuminate\Http\Request;

class MovieVideoController extends Controller
{


    function create($id){

        $movie = Movie::find($id);

        $video = VideoMovieModel::where('movie_id', $id)->get();
        return view('videolinkmanager.moviemanagerlink',compact('movie','video'));
    }


    function storevideo($id,VideoMovieRequest $request){

        $request->validated($request->all());


        $data['lebel'] = $request->lebel;
        $data['movie_id'] = $id;
        $data['quality'] = $request->quality;
        $data['size'] = $request->size;
        $data['source'] = $request->source;
        $data['url'] = $request->url;
        $data['status'] = $request->status;
        $data['type'] = 'movie';

        $video = VideoMovieModel::create($data);
        if (!$video) {
            return redirect(route('showmoviemanager',$id))->with('error','There is Problem With Add Video');
        }
        return redirect(route('showmoviemanager',$id));

    }

    function deletvideo($id){

        $video = VideoMovieModel::findOrFail($id);
        $video->delete();
        return redirect(route('showmoviemanager',$video->movie_id));
    }


    function Editvideo($id){

        $video = VideoMovieModel::Find($id);
        return redirect(route('showmoviemanager',$video->movie_id));
    }
}
