<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserRequest;
use App\Models\User;
use Illuminate\Http\Request;

class UserManager extends Controller
{



    public function Show()
    {

        $users = User::paginate(8);

        if (isset($_GET['query'])) {

            $textsearch = $_GET['query'];

            $result = User::where('name', 'LIKE', '%' . $textsearch . '%')->paginate(8);


            return view('layout.users', compact('users', 'result'));
        }

        return view('layout.users', compact('users'));
    }

    public function AddUser(UserRequest $request)
    {

        $request->validated($request->all());


        $data['name'] = $request->name;
        $data['email'] = $request->email;
        $data['Subscription'] = $request->Subscription;
        $data['profil'] = $request->profil;
        $data['password'] = $request->password;


        $video = User::create($data);
        if (!$video) {
            return redirect(route('users'))->with('error', 'There is Problem With Add Video');
        }
        return redirect(route('users'));
    }


    public function EditUser($id, UserRequest $request)
    {

        $request->validated($request->all());

        $movie = User::find($id);

        $data['name'] = $request->name;
        $data['email'] = $request->email;
        $data['Subscription'] = $request->Subscription;
        $data['profil'] = $request->profil;
        $data['password'] = $request->password;


        $movie->save();


        return redirect(route('users'));
    }

    public function DeletUser($id)
    {
        $movie = User::findOrFail($id);
        $movie->delete();

        return redirect(route('users'));
    }
}
