<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Http\Requests\TvRequest;
use App\Models\TV;



class AddTVcontroller extends Controller
{


    function create()
    {

        return view('layout.tvshow.addtv');
    }

    function addtv(TvRequest $request)
    {


        $request->validated($request->all());


        $data['title'] = $request->title;
        $data['poster'] = $request->poster;
        $data['cover'] = $request->cover;
        $data['year'] = $request->year;
        $data['place'] = $request->status.','.'tv';
        $data['gener'] = $request->gener;
        $data['country'] = $request->country;
        $data['age'] = $request->age;
        $data['story'] = $request->story;
        $data['tmdb_id'] = $request->tmdbid;

        $movie = TV::create($data);
        if (!$movie) {
            return redirect(route('addtv'))->with('error','There is Problem With Add tv');
        }
        return redirect(route('tv'));
    }



    public function gettvFromTMDB(Request $request){


        $request->validate(['tmdb' => 'required',]);

        $tmdb = $request->tmdb;

        $data = Http::asJson()
            ->get(config('services.tmdb.endpoint').'tv/'.$tmdb. '?api_key='.config('services.tmdb.api'));

            if (empty($data['name'])){

                return back()->with('akhta', 'The TMDB code its not working');
            }


        return view('layout.tvshow.addtv',compact('data'));
    }


    public function edittvcreate($id){

        $movie = TV::find($id);
        //$movie->visit()->customInterval(now());

        return view('layout.tvshow.edittv',compact('movie'));
    }


    function edittv(TvRequest $request,$id){

        $request->validated($request->all());

        $movie = TV::find($id);

        $movie['title'] = $request->title;
        $movie['poster'] = $request->poster;
        $movie['cover'] = $request->cover;
        $movie['year'] = $request->year;
        $movie['place'] = $request->status.','.'tv';
        $movie['gener'] = $request->gener;
        $movie['country'] = $request->country;
        $movie['age'] = $request->age;
        $movie['story'] = $request->story;
        $movie['tmdb_id'] = $request->tmdbid;

        $movie->save();


        return redirect(route('tv'));
    }


    function delettv($id){

        $movie = TV::findOrFail($id);
        $movie->delete();
        return redirect(route('tv'));

    }
}
