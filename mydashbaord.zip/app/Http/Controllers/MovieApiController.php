<?php

namespace App\Http\Controllers;

use App\Http\Resources\MovieResource;
use App\Models\Movie;
use App\Models\TV;
use App\Models\VideoMovieModel;
use App\Traits\HttpResponse;
use Illuminate\Http\Request;

class MovieApiController extends Controller
{
    use HttpResponse;
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        $allmovie = Movie::where('place', 'Published')->get();


     

        return MovieResource::collection($allmovie);
        
    }



    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {

        $movie = Movie::findOrFail($id);
        $movie->visit()->customInterval(now());

        $movie['views'] = count($movie['visits']);
        $movie['videos'] = VideoMovieModel::where('movie_id', $id)->get();

        return response()->json($movie);
    }

    public function publishedmovie()
    {

        $allmovie = Movie::where('place', 'Published')->limit(20)->get();


        return MovieResource::collection($allmovie);    }

    public function actionmovie()
    {
        
        //GetActionMovie
        //$allmovie = Movie::where('place', 'Published')->limit(20)->get();
        $mostmovievisted = Movie::where('place', 'LIKE','%' . 'Published'. '%')->limit(10)->get()->toArray();
        $mosttvshowsvisited = TV::where('place', 'LIKE','%' . 'Published'. '%')->limit(10)->get()->toArray();
        
        $merged_array = array_merge($mostmovievisted, $mosttvshowsvisited);


        $collection = collect($merged_array);
 
        $shuffled = $collection->shuffle();
 
        $shuffled->all();

        return MovieResource::collection($shuffled);   
        
        
    }


    public function supreheromovie()
    {

        //$allmovie = Movie::where('gener', 'LIKE', '%' . 'superhero' . '%')->where('place', 'Published')->limit(20)->get();

        $mostmovievisted = Movie::popularAllTime()->orderBy('visit_count_total', 'desc')->where('place', 'LIKE','%' . 'Published'. '%')->limit(10)->get()->toArray();
        $mosttvshowsvisited = TV::popularAllTime()->orderBy('visit_count_total', 'desc')->where('place', 'LIKE','%' . 'Published'. '%')->limit(10)->get()->toArray();
        
        $merged_array = array_merge($mostmovievisted, $mosttvshowsvisited);


        return MovieResource::collection($merged_array);    }


    public function TrendingMovie()
    {

        $mostmovievisted = Movie::popularThisWeek()->where('place', 'LIKE','%' . 'Published'. '%')->limit(10)->get()->toArray();
        $mosttvshowsvisited = TV::popularThisWeek()->where('place', 'LIKE','%' . 'Published'. '%')->limit(10)->get()->toArray();
        
        $merged_array = array_merge($mostmovievisted, $mosttvshowsvisited);
        return MovieResource::collection($merged_array);
        //return $this->success($allmovie);
    }
    
    
    public function allmt()
    {

        $mostmovievisted = Movie::where('place', 'LIKE','%' . 'Published'. '%')->get()->toArray();
        $mosttvshowsvisited = TV::where('place', 'LIKE','%' . 'Published'. '%')->get()->toArray();
        
        $merged_array = array_merge($mostmovievisted, $mosttvshowsvisited);
        return MovieResource::collection($merged_array);
        //return $this->success($allmovie);
    }
    

    public function search($search){

        $movie = Movie::where('title', 'LIKE', '%' . $search . '%')->where('place', 'Published')->get();
        //$tv = TV::where('title', 'LIKE', '%' . $search . '%')->paginate(8);

        return MovieResource::collection($movie);

    }
}

