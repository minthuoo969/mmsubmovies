<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Http;

use App\Http\Requests\BulkRequest;
use App\Models\Movie;
use App\Models\TV;

use Illuminate\Http\Request;

class TvBulk extends Controller
{
    
    public function tvshowsbulk()
    {
        
        return view('layout.bulktv');
        
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function savetvshowsbulk(BulkRequest $request)
    {
         $request->validated($request->all());


        $movies_ids = explode (",", $request->movies);

        $counter = 1;

        foreach ($movies_ids as $value) {

            $results = Http::asJson()
            ->get(config('services.tmdb.endpoint').'tv/'.$value. '?api_key='.config('services.tmdb.api'));

           if ($results != null) {
            $data['title'] = $results['name'];
            $data['poster'] = 'https://www.themoviedb.org/t/p/w600_and_h900_face'.$results['poster_path'];
            $data['cover'] = 'https://www.themoviedb.org/t/p/w600_and_h900_face'.$results['backdrop_path'];
            $data['year'] = date('Y',strtotime($results['first_air_date']));
            $data['place'] = $request->status.','.'tv';
            $gener = '';
            foreach ($results['genres'] as $value) {

                    $gener .=  $value['name'].',';

            }
            $data['gener'] = $gener;
            $data['country'] = $results['production_countries'][0]['name'];
            $data['age'] = '+15';
            $data['story'] = $results['overview'];
            $data['tmdb_id'] = $results['id'];

            TV::create($data);

            $counter++;

            if ($counter > count($movies_ids)) {
                return redirect(route('getbulkview'));
            }
           }

            // $isthere = Movie::where('tmdb_id',$results['id'])->first();

            //   if ($isthere->exists()) {
            //     return redirect(route('getbulkview'))->with('error', 'the Movie with Id : '.$results['id'].' exists');
            //   }



        }
    }


}
