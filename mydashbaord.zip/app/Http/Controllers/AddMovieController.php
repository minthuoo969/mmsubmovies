<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;
use App\Http\Requests\MovieRequest;
use App\Models\Movie;
use Ladumor\OneSignal\OneSignal;

class AddMovieController extends Controller
{


    function create()
    {

        return view('layout.movie.addmovie');
    }


    public function getMovieFromTMDB(Request $request)
    {


        $request->validate(['tmdb' => 'required',]);

        $tmdb = $request->tmdb;

        $data = Http::asJson()
            ->get(config('services.tmdb.endpoint') . 'movie/' . $tmdb . '?api_key=' . config('services.tmdb.api'));

        if (empty($data['title'])) {

            return back()->with('akhta', 'The TMDB code its not working');
        }


        return view('layout.movie.addmovie', compact('data'));
    }


    function createmovie(MovieRequest $request)
    {


        $request->validated($request->all());


        $data['title'] = $request->title;
        $data['poster'] = $request->poster;
        $data['cover'] = $request->cover;
        $data['year'] = $request->year;
        $data['place'] = $request->status.','.'movie';
        $data['gener'] = $request->gener;
        $data['country'] = $request->country;
        $data['age'] = $request->age;
        $data['story'] = $request->story;
        $data['tmdb_id'] = $request->tmdbid;

        $movie = Movie::create($data);
        if (!$movie) {
            return redirect(route('addmovie'))->with('error', 'There is Problem With Add Movie');
        }
        return redirect(route('movie'));
    }


    public function editmoviecreate($id)
    {

        $movie = Movie::findOrFail($id);
        //$movie->visit()->customInterval(now());



        return view('layout.movie.editmovie', compact('movie'));
    }


    function editmovie(MovieRequest $request, $id)
    {

        $request->validated($request->all());

        $movie = Movie::find($id);

        $movie['title'] = $request->title;
        $movie['poster'] = $request->poster;
        $movie['cover'] = $request->cover;
        $movie['year'] = $request->year;
        $movie['place'] = $request->status.','.'movie';
        $movie['gener'] = $request->gener;
        $movie['country'] = $request->country;
        $movie['age'] = $request->age;
        $movie['story'] = $request->story;
        $movie['tmdb_id'] = $request->tmdbid;

        $movie->save();


        return redirect(route('movie'));
    }
}
