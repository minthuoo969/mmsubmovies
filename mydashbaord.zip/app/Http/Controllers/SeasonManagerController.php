<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Http;
use App\Http\Requests\SeasonRequest;
use App\Models\episodemodel;
use App\Models\SeasonModel;
use App\Models\TV;
use Illuminate\Http\Request;

class SeasonManagerController extends Controller
{


    public function create($id)
    {


        $tv = TV::find($id);

        $seasons = SeasonModel::where('movie_id', $id)->get();





        return view('layout.tvshow.managerseason', compact('tv', 'seasons'));
    }



    public function addseason($id,SeasonRequest $request)
    {
        $request->validated($request->all());


        $data['name'] = 'season '.$request->name;
        $data['movie_id'] = $id;
        $data['Episodes'] = episodemodel::where(['tv_id' => $id, 'season_id' => $request->id ])->count();
        $data['status'] = $request->status;


        $video = SeasonModel::create($data);
        if (!$video) {
            return redirect(route('managerseason.create', $id))->with('error', 'There is Problem With Add Video');
        }
        return redirect(route('managerseason.create', $id));
    }

 public function getSeasonsFromTMDB($id)
    {
       
        

        $data = Http::asJson()
            ->get(config('services.tmdb.endpoint').'tv/'.$id. '?api_key='.config('services.tmdb.api'));

            if (empty($data['name'])){

                return back()->with('error', 'There is Problem With Add Video');
            }
            
            //dd($data['seasons']);
            
            foreach ($data['seasons'] as $season) {
                
                
                
                 $myseason['name'] = $season['name'];
                 $myseason['movie_id'] = $id;
                 $myseason['Episodes'] = $season['episode_count'];
                 $myseason['status'] = 'Published';


                 $video = SeasonModel::create($myseason);
                 if (!$video) {
                        return redirect(route('managerseason.create', $id))->with('error', 'There is Problem With Add Video');
                    }
            }
            
            




        return redirect(route('managerseason.create', $id));
        

       
       
    }


    public function deletseason($id){

        $movie = SeasonModel::findOrFail($id);
        $movie->delete();

        $tv = TV::find($movie->movie_id);
        return redirect(route('managerseason.create', $tv));
    }




}
