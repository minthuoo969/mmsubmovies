<?php

namespace App\Http\Controllers;

use App\Http\Requests\MovieRequest;
use App\Models\Movie;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Http;

class MovieController extends Controller
{


    public function Show(Request $request)
    {

        $allmovies = Movie::paginate(8);

        if (isset($_GET['query'])) {

            $textsearch = $_GET['query'];

            $result = Movie::where('title', 'LIKE', '%' . $textsearch . '%')->paginate(8);


            return view('layout.movie.movie', compact('allmovies', 'result'));
        }


        return view('layout.movie.movie', compact('allmovies'));
    }




    function create()
    {

        return view('layout.movie.addmovie');
    }


    function addmovie(MovieRequest $request)
    {


        $request->validated();


        $data['title'] = $request->title;
        $data['poster'] = $request->poster;
        $data['year'] = $request->year;
        $data['place'] = $request->status.','.'movie';
        $data['gener'] = $request->gener;
        $data['country'] = $request->country;
        $data['age'] = $request->age;
        $data['story'] = $request->story;
        $data['tmdb_id'] = $request->tmdb_id;

        $movie = Movie::create($data);
        if (!$movie) {
            return redirect(route('addmovie.post'));
        }
        return redirect(route('movie'));
    }



    public function getMovieFromeTMDB(Request $request){


        $request->validate(['tmdb_id' => 'required',]);

        $tmdb_id = $request->tmdb_id;

        $data = Http::asJson()
            ->get(config('services.tmdb.endpoint').'movie/'.$tmdb_id. '?api_key='.config('services.tmdb.api'));

        return view('layout.movie.addmovie',compact('data'));
    }




    function deletmovie($id)
    {


        $movie = Movie::findOrFail($id);
        $movie->delete();
        return redirect(route('movie'));


    }
}
