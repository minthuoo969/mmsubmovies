<?php

namespace App\Http\Controllers;

use App\Http\Requests\EpisodeTVeq;
use App\Http\Resources\MovieResource;
use App\Models\episodemodel;
use App\Models\SeasonModel;
use App\Models\TV;
use App\Traits\HttpResponse;
use Illuminate\Http\Request;

class TvApiController extends Controller
{
    use HttpResponse;
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        $alltv = TV::where('place', 'Published')->paginate(9);

        return MovieResource::collection($alltv);
    }


    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $movie = TV::findOrFail($id);
        $movie->visit()->customInterval(now());

        $movie['views'] = count($movie['visits']);
        $movie['Seasons'] = SeasonModel::where('movie_id', $id)->get();

        return response()->json($movie);
    }

    public function actiontv()
    {

        $allmovie = TV::where('gener', 'LIKE', '%' . 'action' . '%')->limit(10)->get();


        return $this->success($allmovie);
    }


    public function supreherotv()
    {

        $allmovie = TV::where('gener', 'LIKE', '%' . 'superhero' . '%')->limit(10)->get();


        return $this->success($allmovie);
    }


    public function Trendingtv()
    {

        $allmovie = TV::popularAllTime()->orderBy('visit_count_total', 'desc')->limit(10)->get();

        return MovieResource::collection($allmovie);
        //return $this->success($allmovie);
    }
    public function search($search){

        $tv = TV::where('title', 'LIKE', '%' . $search . '%')->paginate(8);

        return MovieResource::collection($tv);

    }
    
    public function episdoesofseason(string $id)
    {
        $season = SeasonModel::findOrFail($id);
        if ($season == null) {
            return response()->json('[]');
        }
               
        $video = episodemodel::where(['season_id' => $id, 'tv_id' => $season['movie_id']])->get();


        return response()->json($video);
    }

    

}
