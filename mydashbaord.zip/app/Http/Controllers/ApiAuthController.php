<?php

namespace App\Http\Controllers;

use App\Http\Requests\LoginUserRequest;
use App\Http\Requests\StoreUserRequest;
use App\Models\User;
use App\Traits\HttpResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

use Illuminate\Support\Facades\Hash;

class ApiAuthController extends Controller
{
    use HttpResponse;


    public function login(LoginUserRequest $request)
    {


        $request->validate(([
            'email' => 'required|email',
            'password' => 'required|min:5|max:12'
        ]));

        if (!Auth::attempt($request->only(['email', 'password']))) {
            return response()->json(['error' => 'Credentials do not match']);
        }

        $user = User::where('email', '=', $request->email)->first();


        if ($user) {
            if (Hash::check($request->password, $user->password)) {
                return response()->json([
                    'user' => $user,
                    'token' => $user->createToken('API Token of ' . $user->name)->plainTextToken
                ]);
            } else {
                return response()->json(['error' => 'password not matches']);
            }
        } else {
            return response()->json(['error' => 'this email is not registred']);
        }
    }


    public function chackeemail($email){

        $user = User::where('email', '=', $email)->first();

        if ($user) {

            return response()->json(['error' => 'email existe']);

        }else {
            return response()->json(['msj' => 'no user']);
        }


    }


    public function register(LoginUserRequest $request)
    {


        $request->validate(([
            'email' => 'required|email',
            'name' => 'required',
            'password' => 'required|min:5|max:12'
        ]));


        $data['name'] = $request->name;
        $data['email'] = $request->email;
        $data['Subscription'] = $request->Subscription;
        $data['profil'] = $request->profil;
        $data['password'] = Hash::make($request->password);

        $user = User::create($data);
        if ($user) {

            return response()->json([
                'user' => $user,
                'token' => $user->createToken('API Token of ' . $user->name)->plainTextToken
            ]);
        }else{
            return response()->json([
                'msj' => 'error in sign up'
            ]);
        }

    }

    public function logout()
    {

        Auth::user()->currentAccessToken()->delet();

        return response()->json([
            'message' => 'Successfully logged out'
        ]);
    }
}
