<?php

namespace App\Http\Controllers;

use App\Http\Resources\MovieResource;
use App\Models\GenerModel;
use App\Http\Requests\GenerRequest;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class GenersController extends Controller
{




    public function create()
    {

        $geners = GenerModel::paginate(8);

        if (isset($_GET['query'])) {

            $textsearch = $_GET['query'];

            $result = GenerModel::where('name', 'LIKE', '%' . $textsearch . '%')->paginate(8);


            return view('layout.geners', compact('geners', 'result'));
        }

        return view('layout.geners', compact('geners'));
    }


     public function getgeners()
    {

        $geners = GenerModel::all();

        

         return MovieResource::collection($geners); 
    }


    public function addgeners(GenerRequest $request)
    {

        $request->validated($request->all());


        $data['name'] = $request->name;
        $data['icon'] = $request->icon;
        $data['status'] = $request->status;


        $video = GenerModel::create($data);
        if (!$video) {
            return redirect(route('geners'))->with('error', 'There is Problem With Add Video');
        }
        return redirect(route('geners'));
    }


    function editGener($id,GenerRequest $request)
    {

        $request->validated($request->all());

        $movie = GenerModel::find($id);

        $data['name'] = $request->name;
        $data['icon'] = $request->icon;
        $data['status'] = $request->status;


        $movie->save();


        return redirect(route('geners'));
    }


    public function delet($id)
    {

        $movie = GenerModel::findOrFail($id);
        $movie->delete();

        return redirect(route('geners'));
    }
}
