<?php

namespace App\Http\Controllers;


use Illuminate\Support\Facades\Http;
use App\Http\Requests\TvRequest;
use App\Models\TV;
use Illuminate\Http\Request;

class TVController extends Controller
{



    function create()
    {

        $allmovies = TV::paginate(8);

        if (isset($_GET['query'])) {

            $textsearch = $_GET['query'];

            $result = TV::where('title', 'LIKE', '%' . $textsearch . '%')->paginate(8);


            return view('layout.tvshow.tv', compact('allmovies', 'result'));
        }


        return view('layout.tvshow.tv', compact('allmovies'));
    }



}
