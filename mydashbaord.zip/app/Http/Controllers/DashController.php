<?php

namespace App\Http\Controllers;

use App\Models\episodemodel;
use App\Models\Movie;
use App\Models\TV;
use App\Models\TVShow;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\viewsmodel;
use Illuminate\Support\Facades\Session;

class DashController extends Controller
{


    public function show(){


        // $data = array();
        // if (session()->has('loginId')){
        //     $data = User::where('id','=',Session::has('loginId'))->first();
        // }

        $usercount = User::count();
        $moviecount = Movie::count();
        $tvcount = TV::count();
        $videocount = episodemodel::count();


        $allusers = User::orderBy('created_at', 'desc')->paginate(10);
        $movievisitedtoday = Movie::popularToday()->orderBy('visit_count_total', 'desc')->limit(10)->get();
        $tvshowsvisitedtoday = TV::popularToday()->orderBy('visit_count_total', 'desc')->limit(10)->get();


        $mostmovievisted = Movie::popularAllTime()->orderBy('visit_count_total', 'desc')->limit(10)->get();
        $mosttvshowsvisited = TV::popularAllTime()->orderBy('visit_count_total', 'desc')->limit(10)->get();





        return view('layout.dashbaord',compact(
            'usercount','allusers','moviecount','videocount','movievisitedtoday','tvcount','tvshowsvisitedtoday','mostmovievisted','mosttvshowsvisited'));
    }


}
