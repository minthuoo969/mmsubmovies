<?php

namespace App\Http\Controllers;

use App\Http\Requests\episoderequest;
use App\Models\episodemodel;
use App\Models\SeasonModel;
use App\Models\TV;
use Illuminate\Http\Request;

class episodecountroller extends Controller
{


    function create($id){


        $season = SeasonModel::find($id);

        $tv = TV::find($season->movie_id);


        $video = episodemodel::where(['season_id' => $id, 'tv_id' => $season['movie_id']])->get();


        return view('layout.tvshow.managerepisoe',compact('tv','video','season'));
    }


    function storevideo($id,episoderequest $request){

        $request->validated($request->all());


        $season = SeasonModel::find($id);


        $data['lebel'] = $request->lebel;
        $data['tv_id'] = $season['movie_id'];
        $data['season_id'] = $id;
        $data['quality'] = $request->quality;
        $data['size'] = $request->size;
        $data['source'] = $request->source;
        $data['url'] = $request->url;
        $data['status'] = $request->status;
        $data['type'] = 'tv';

        $video = episodemodel::create($data);
        if (!$video) {
            return redirect(route('showepisodes',$id))->with('error','There is Problem With Add Video');
        }
        return redirect(route('showepisodes',$id));

    }

    function deleepisodeideo($id){
        $epe = episodemodel::find($id);

        $video = episodemodel::findOrFail($id);
        $video->delete();
        return redirect(route('showepisodes',$epe->season_id));
    }



}
