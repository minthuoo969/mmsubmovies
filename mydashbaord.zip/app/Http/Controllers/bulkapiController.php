<?php

namespace App\Http\Controllers;

use App\Http\Resources\MovieResource;
use App\Models\skipgooglemodel;
use App\Traits\HttpResponse;
use Illuminate\Http\Request;

class bulkapiController extends Controller
{ use HttpResponse;
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        if (skipgooglemodel::find(1) == null) {
            return $this->error([],'problem',404);
        }

        $data = skipgooglemodel::find(1);

        return response()->json($data);



    }




}
