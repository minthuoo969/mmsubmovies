<?php $__env->startSection('title', 'Manage Episodes'); ?>

<?php $__env->startSection('contant'); ?>


    <div class="create-movie">

        <?php if($errors->any()): ?>
            <div class="col-12">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h4 class="textsucc"><?php echo e($error); ?></h4>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        <?php endif; ?>


        <form action="<?php echo e(route('storevideo',$season['id'])); ?>" method="post">
            <?php echo csrf_field(); ?>

            <div class="importdata">



                <div class="meddle">
                    <div class="container-movies-2">
                        <main>


                            <div class="all-movies">

                                <section class="movie-section">


                                    <div class="king-info">

                                        <div class="containertow2">
                                            <div class="Movie-Info">
                                                <h2>Add Videos (<?php echo e($tv['title']); ?>   Season <?php echo e($season['name']); ?>)</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Label</b></h2>

                                                        <input type="text" name="lebel" class="record-tmdb_id"
                                                            value="<?php echo e(old('lebel')); ?>">

                                                </div>


                                                <div class="m-title">
                                                    <h3><b>Quality</b></h2>

                                                        <input type="text" name="quality" class="record-tmdb_id"
                                                            value="<?php echo e(old('quality')); ?>">

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Size</b></h2>

                                                        <input type="text" name="size" class="record-tmdb_id"
                                                            value="<?php echo e(old('size')); ?>">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Source</b></h2>


                                                        <select name="source">

                                                            <?php $__currentLoopData = json_decode(
            '{
                                                                                "Youtube":"Youtube",
                                                                                "Mp4":"Mp4 From Url",
                                                                                "Mkv":"Mkv From Url",
                                                                                "M3u8":"M3u8 From Url",
                                                                                "Dash":"Dash From Url",
                                                                                "Embed":"Embed Url",
                                                                                "Dailymotion":"Dailymotion",
                                                                                "DoodStream":"DoodStream",
                                                                                "Dropbox":"Dropbox",
                                                                                "Facebook":"Facebook",
                                                                                "MixDrop":"MixDrop",
                                                                                "OKru":"OKru",
                                                                                "StreamSB":"StreamSB",
                                                                                "StreamTape":"StreamTape",
                                                                                "VK":"VK",
                                                                                "Vimeo":"Vimeo"
                                                                             }',
            true,
        ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionKey => $optionValu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($optionKey); ?>"><?php echo e($optionValu); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </select>

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Url</b></h2>

                                                        <input type="text" name="url" class="record-tmdb_id"
                                                            value="<?php echo e(old('url')); ?>">

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Status</b></h2>


                                                        <select name="status">

                                                            <?php $__currentLoopData = json_decode('{"Published":"Published","Unpublished":"Unpublished"}', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionKey => $optionValu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($optionKey); ?>"><?php echo e($optionValu); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </select>

                                                </div>
                                                <div class="addmoviebtn">

                                                    <button class="fetch-btn">Add Video</button>

                                                </div>



                                            </div>

                                        </div>


                                    </div>


                                    <div class="kingalvideo">
                                        <div class="record-header">
                                            <div class="add">
                                                <span>Page</span>
                                                <select name="" id="">
                                                    <option value="">ID</option>
                                                </select>
                                                
                                            </div>



                                        </div>

                                        <?php if(count($video) > 0): ?>

                                            <table>

                                                <thead>
                                                    <tr>
                                                        <th>Option</th>
                                                        <th>Label</th>
                                                        <th>Source</th>
                                                        <th>Url</th>
                                                        <th>Status</th>
                                                        <th>Quality</th>
                                                        <th>Size</th>
                                                    </tr>
                                                </thead>
                                                <tbody>



                                                    <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>

                                                            <td class="btn-edit">
                                                                <div class="dropdown">
                                                                    <div class="select">
                                                                        <span class="selected">Options</span>
                                                                        <div class="caret"></div>
                                                                    </div>
                                                                    <ul class="menu">
                                                                        <li><a
                                                                                href="<?php echo e(route('deleepisodeideo', $user['id'])); ?>">Delete</a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </td>
                                                            <td class="mytitle"><?php echo e($user['lebel']); ?></td>
                                                            <td><?php echo e($user['source']); ?></td>
                                                            <td class="myurl"><?php echo e($user['url']); ?></td>
                                                            <td class="warning"><?php echo e($user['status']); ?></td>
                                                            <td class="mytitle"><?php echo e($user['quality']); ?></td>
                                                            <td class="mytitle"><?php echo e($user['size']); ?></td>

                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                </tbody>

                                            </table>
                                        <?php else: ?>
                                            <h2 class="modatavideo">No Videos Added Yet</h2>


                                        <?php endif; ?>



                                    </div>


                                </section>



                            </div>



                        </main>


                    </div>
                </div>



            </div>







        </form>
    </div>








<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\laravel projects\anass\resources\views/layout/tvshow/managerepisoe.blade.php ENDPATH**/ ?>