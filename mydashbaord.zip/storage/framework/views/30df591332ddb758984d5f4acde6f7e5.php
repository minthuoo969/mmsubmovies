<?php $__env->startSection('title', 'EDIT TV'); ?>

<?php $__env->startSection('contant'); ?>


    <div class="create-movie">

        <?php if($errors->any()): ?>
        <div class="col-12">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h4 class="textsucc"><?php echo e($error); ?></h4>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    <?php endif; ?>
        <form action="<?php echo e(route('edittv',$movie['id'])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="importdata">

                <?php if(isset($movie)): ?>

                <div class="meddle">
                    <div class="container-movies-2">
                        <main>


                            <div class="all-movies">

                                <section class="movie-section">


                                    <div class="king-info">

                                        <div class="containertow">
                                            <div class="Movie-Info">
                                                <h2>TV Info</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Title</b></h2>




                                                        <input type="text" name="title" class="record-tmdb_id"
                                                        <?php if($movie['title'] ): ?>
                                                        value="<?php echo e($movie['title']); ?>"

                                                    <?php endif; ?> value="<?php echo e(old('title')); ?>">

                                                </div>


                                                <div class="m-title">
                                                    <h3><b>Description</b></h2>



                                                        <textarea name="story" id="text-desc" rows="5" value="ddd"><?php if($movie['story']): ?> <?php echo e($movie['story']); ?> <?php endif; ?></textarea><p class="counter" id="result"></p>

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Geners</b></h2>

                                                        <p>add a comma after each tag</p>
                                                        <input type="text" name="gener"


                                                       value="<?php echo e($movie['gener']); ?>"




                                                            placeholder="action,comedy,horror.....">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Release Date</b></h2>


                                                        <input type="text" name="year"

                                                        value="<?php echo e(date('Y',strtotime($movie['year']))); ?>"
                                                            placeholder="add year : 2024..." class="record-date">

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Country</b></h2>


                                                        <input type="text" name="country" value="<?php echo e(old('country')); ?>"
                                                            placeholder="usa,canada,japon..." class="record-date">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Age</b></h2>


                                                        <input type="text" name="age" placeholder="+13,+14,+18....."
                                                            class="record-date" value="<?php echo e(old('age')); ?>">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>TMDB ID</b></h2>


                                                        <input type="text" name="tmdbid" placeholder="264633..."
                                                            class="record-date" value="<?php echo e($movie['tmdb_id']); ?>">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Status</b></h2>


                                                        <select name="status">

                                                            <?php $__currentLoopData = json_decode('{"Published":"Published","Unpublished":"Unpublished"}', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionKey => $optionValu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($optionKey); ?>"><?php echo e($optionValu); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </select>

                                                </div>





                                            </div>
                                            <div class="Movie-Info-2">
                                                <h2>Additional Info</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Thumbnail</b></h2>

                                                        <div class="img-poster">
                                                            <img id="poster"
                                                                src="<?php echo e($movie['poster']); ?>" alt="">


                                                        </div>
                                                        <div class="fetch">

                                                            <input type="text" name="poster" id="posterlink"
                                                            <?php if(isset($movie['poster'])): ?> value="<?php echo e($movie['poster']); ?>"
                                                            <?php endif; ?>

                                                                placeholder="Image URL (Best Fit = 500 x 750)"
                                                                class="record-poster">

                                                            <div class="input-box button">

                                                                <input id="setposter" class="fetch-btn" type="button"
                                                                    value="SET">

                                                            </div>
                                                        </div>
                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Poster</b></h2>

                                                        <div class="img-poster">
                                                            <img  class="cover" id="cover"
                                                                <?php if(isset($movie['cover'])): ?> src=" <?php echo e($movie['cover']); ?>"
                                                            <?php else: ?>
                                                            src=" https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ngl2FKBlU4fhbdsrtdom9LVLBXw.jpg " <?php endif; ?>
                                                                alt="">



                                                        </div>
                                                        <div class="fetch">

                                                            <input type="text" name="cover" id="coverlink"
                                                            <?php if(isset($movie['cover'])): ?> value="<?php echo e($movie['cover']); ?>"
                                                            <?php endif; ?>

                                                                placeholder="Image URL (Best Fit = 2048 x 1152)"
                                                                class="record-poster">

                                                            <div class="input-box button">
                                                                <input id="setcover" class="fetch-btn" type="button"
                                                                    value="SET">

                                                            </div>

                                                        </div>
                                                </div>



                                            </div>
                                        </div>

                                    </div>




                                </section>



                            </div>



                        </main>


                    </div>
                </div>

                <?php else: ?>

                <div class="meddle">
                    <div class="container-movies-2">
                        <main>


                            <div class="all-movies">

                                <section class="movie-section">


                                    <div class="king-info">

                                        <div class="containertow">
                                            <div class="Movie-Info">
                                                <h2>TV Info</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Title</b></h2>




                                                        <input type="text" name="title" class="record-tmdb_id" value="<?php echo e(old('title')); ?>">

                                                </div>


                                                <div class="m-title">
                                                    <h3><b>Description</b></h2>



                                                        <textarea name="story" id="text-desc" rows="5" value="ddd"><?php echo e(old('story')); ?></textarea><p class="counter" id="result"></p>

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Geners</b></h2>

                                                        <p>add a comma after each tag</p>
                                                        <input type="text" name="gener"







                                                       value="<?php echo e(old('gener')); ?>"









                                                            placeholder="action,comedy,horror.....">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Release Date</b></h2>


                                                        <input type="text" name="year"

                                                        value="<?php echo e(old('year')); ?>"
                                                            placeholder="add year : 2024..." class="record-date">

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Country</b></h2>


                                                        <input type="text" name="country" value="<?php echo e(old('country')); ?>"
                                                            placeholder="usa,canada,japon..." class="record-date">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Age</b></h2>


                                                        <input type="text" name="age" placeholder="+13,+14,+18....."
                                                            class="record-date" value="<?php echo e(old('age')); ?>">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>TMDB ID</b></h2>


                                                        <input type="text" name="tmdbid" placeholder="264633..."
                                                            class="record-date" value="<?php echo e(old('tmdbid')); ?>">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Status</b></h2>


                                                        <select name="status">

                                                            <?php $__currentLoopData = json_decode('{"Published":"Published","Unpublished":"Unpublished"}', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionKey => $optionValu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($optionKey); ?>"><?php echo e($optionValu); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </select>

                                                </div>





                                            </div>
                                            <div class="Movie-Info-2">
                                                <h2>Additional Info</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Thumbnail</b></h2>

                                                        <div class="img-poster">
                                                            <img id="poster"

                                                            src=" https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ngl2FKBlU4fhbdsrtdom9LVLBXw.jpg "
                                                                alt="">


                                                        </div>
                                                        <div class="fetch">

                                                            <input type="text" name="poster" id="posterlink"
                                                                value="<?php echo e(old('poster')); ?>"
                                                                placeholder="Image URL (Best Fit = 500 x 750)"
                                                                class="record-poster">

                                                            <div class="input-box button">

                                                                <input id="setposter" class="fetch-btn" type="button"
                                                                    value="SET">

                                                            </div>
                                                        </div>
                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Poster</b></h2>

                                                        <div class="img-poster">
                                                            <img  class="cover" id="cover"

                                                            src=" https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ngl2FKBlU4fhbdsrtdom9LVLBXw.jpg "
                                                                alt="">



                                                        </div>
                                                        <div class="fetch">

                                                            <input type="text" name="cover" id="coverlink"
                                                                value="<?php echo e(old('cover')); ?>"
                                                                placeholder="Image URL (Best Fit = 2048 x 1152)"
                                                                class="record-poster">

                                                            <div class="input-box button">
                                                                <input id="setcover" class="fetch-btn" type="button"
                                                                    value="SET">

                                                            </div>

                                                        </div>
                                                </div>



                                            </div>
                                        </div>

                                    </div>




                                </section>



                            </div>



                        </main>


                    </div>
                </div>
                <?php endif; ?>

                <div class="addmoviebtn">

                    <button class="fetch-btn">Update TV</button>

                </div>
            </div>




        </form>
    </div>




    <script>
        const setposter = document.getElementById('setposter');
        var posterlink = document.getElementById('posterlink');
        var poster = document.getElementById('poster');

        const setcover = document.getElementById('setcover');
        var coverlink = document.getElementById('coverlink');
        var cover = document.getElementById('cover');



        setposter.addEventListener('click', () => {

            poster.src = posterlink.value;

        });


        setcover.addEventListener('click', () => {

            cover.src = coverlink.value;

        });
    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/hypering/jseries.hyperwatching.com/resources/views/layout/tvshow/edittv.blade.php ENDPATH**/ ?>