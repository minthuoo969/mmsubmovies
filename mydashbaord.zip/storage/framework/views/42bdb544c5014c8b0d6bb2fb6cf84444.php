<?php $__env->startSection('title', 'ADD MOVIE'); ?>

<?php $__env->startSection('contant'); ?>


<div class="create-movie">
    <form action="<?php echo e(route('addmovie.post')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="importdata">


            <div class="top">
                <h4 class="textaround">Import Contents From TMDB</h4>
                <div class="fetch">

                        <input type="text" value="<?php echo e(old('tmdb_id')); ?>" name="tmdb_id" placeholder="Enter TMDB ID. Ex: 38846" value="<?php echo e(old('tmdb_id')); ?>" class="record-tmdb_id">



                    <button>Fetch</button>

                </div>
                <h3>Get IMDB ID from here : <a href="https://www.themoviedb.org"> TheMovieDB.org</a></h3>

                
                <?php if($errors->any()): ?>
                    <div class="col-12">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h4 class="textsucc"><?php echo e($error); ?></h4>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                <?php endif; ?>

            </div>
            <div class="meddle">
                <div class="container-movies-2">
                    <main>


                        <div class="all-movies">

                            <section class="movie-section">


                                <div class="king-info">

                                    <div class="containertow">
                                        <div class="Movie-Info">
                                            <h2>Movie Info</h2>
                                            <hr>
                                            <div class="m-title">
                                                <h3><b>Title</b></h2>



                                                        <input type="text" name="title" class="record-tmdb_id">

                                            </div>


                                            <div class="m-title">
                                                <h3><b>Description</b></h2>



                                                        <textarea name="story" id="text-desc" rows="5"></textarea>
                                                        <p class="counter" id="result"></p>

                                            </div>

                                            <div class="m-title">
                                                <h3><b>Geners</b></h2>

                                                    <p>add a comma after each tag</p>
                                                        <input type="text" name="gener" placeholder="action,comedy,horror....."
                                                            >

                                            </div>
                                            <div class="m-title">
                                                <h3><b>Release Date</b></h2>


                                                        <input type="text" name="year" placeholder="add year : 2024..."
                                                            class="record-date">

                                            </div>

                                            <div class="m-title">
                                                <h3><b>Country</b></h2>


                                                        <input type="text" name="country" placeholder="usa,canada,japon..."
                                                            class="record-date">

                                            </div>
                                            <div class="m-title">
                                                <h3><b>Age</b></h2>


                                                        <input type="text" name="age" placeholder="+13,+14,+18....."
                                                            class="record-date">

                                            </div>

                                        </div>
                                        <div class="Movie-Info-2">
                                            <h2>Additional Info</h2>
                                            <hr>
                                            <div class="m-title">
                                                <h3><b>Thumbnail</b></h2>

                                                    <div class="img-poster">
                                                        <img src="https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ngl2FKBlU4fhbdsrtdom9LVLBXw.jpg"
                                                            alt="">


                                                    </div>
                                                    <div class="fetch">

                                                            <input type="text" name="poster"
                                                                placeholder="Image URL (Best Fit = 500 x 750)" class="record-poster">

                                                        <button id="set">SET</button>

                                                    </div>
                                            </div>
                                            <div class="m-title">
                                                <h3><b>Poster</b></h2>

                                                    <div class="img-poster">
                                                        <img class="cover"
                                                            src="https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ngl2FKBlU4fhbdsrtdom9LVLBXw.jpg"
                                                            alt="">


                                                    </div>
                                                    <div class="fetch">

                                                            <input type="text" name="cover"
                                                                placeholder="Image URL (Best Fit = 2048 x 1152)" class="record-poster">

                                                        <button>SET</button>

                                                    </div>
                                            </div>



                                        </div>
                                    </div>

                                </div>




                            </section>



                        </div>



                    </main>


                </div>
            </div>



        </div>




    </form>
</div>








<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\laravel projects\anass\resources\views/layout/ccmovie.blade.php ENDPATH**/ ?>