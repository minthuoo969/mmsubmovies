<?php $__env->startSection('title','BULK MOVIES'); ?>

<?php $__env->startSection('contant'); ?>
<div class="home-bulk">


    <?php if($errors->any()): ?>
    <div class="col-12">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h4 class="textsucc"><?php echo e($error); ?></h4>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php endif; ?>

    <form action="<?php echo e(route('savebulk')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <div class="Movie-bulk">
            <h2>BULK MOVIES : ADD A LOT OF MOVIES WITH SINGLE CLICK</h2>
            <hr>


            <div class="m-title">
                <h3><b>Movies's TMDB IDs</b></h2>



                    <textarea name="movies" placeholder="Add , After each ID like : 264866,667896,6678748,.."  id="text-desc" rows="5" ><?php echo e(old('story')); ?></textarea>

            </div>


            <div class="m-title">
                <h3><b>Status</b></h2>


                    <select name="status">

                        <?php $__currentLoopData = json_decode('{"Published":"Published","Unpublished":"Unpublished"}', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionKey => $optionValu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($optionKey); ?>"><?php echo e($optionValu); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>

            </div>



            <div class="addmoviebtn">

                <button class="fetch-btn">Add Movies</button>

            </div>

        </div>




    </form>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/hypering/jseries.hyperwatching.com/resources/views/layout/subscrib.blade.php ENDPATH**/ ?>