<!DOCTYPE html>
<!-- Coding by CodingNepal | www.codingnepalweb.com -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Admin Dashboard | JSERIES</title>
    <!-- Boxicons CDN Link -->
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
     <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>

     <link rel="stylesheet"
     href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />

     <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">

     <link rel="shortcut icon" href="<?php echo e(asset('asset/home/images/favicon.ico')); ?>" type="image/x-icon">

    <link rel="stylesheet" href="<?php echo e(asset('asset/home/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset/home/css/dashboard.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset/home/css/movie.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset/home/css/addmovie.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset/home/css/videomanager.css')); ?>">

    <script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" defer></script>
    <script>
      window.OneSignal = window.OneSignal || [];
      OneSignal.push(function() {
        OneSignal.init({
          appId: "a0ece461-8e61-4a09-9dcf-a18bdb24b326",
        });
      });
    </script>

   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <i class='bx bxl-c-plus-plus'></i>
      <span class="logo_name">JSERIES</span>
    </div>
      <ul class="nav-links px-0">
        <li>
          <a  class="<?php echo e(request()->is('/') ? 'active' : ''); ?>" href="<?php echo e(route('dash')); ?>" >
            <i class='bx bx-grid-alt' ></i>
            <span class="links_name">Dashboard</span>
          </a>
        </li>
        <li>
          <a class="<?php echo e(request()->is('movie') || request()->is('addmovie') || request()->is('editmovie/*') || request()->is('manage_movie_links/*') ? 'active' : ''); ?>" href="<?php echo e(route('movie')); ?>">
            <i class='bx bx-movie'></i>
            <span class="links_name">Movies</span>
          </a>
        </li>
        <li>
          <a class="<?php echo e(request()->is('tv') || request()->is('addtv') || request()->is('edittv/*') || request()->is('manage_seasons/*') || request()->is('manage_tv_links/*') ? 'active' : ''); ?>" href="<?php echo e(route('tv')); ?>">
            <i class='bx bx-tv' ></i>
            <span class="links_name">TV</span>
          </a>
        </li>
        <li>
          <a  class="<?php echo e(request()->is('geners') ? 'active' : ''); ?>" href="<?php echo e(route('geners')); ?>">
            <i class='bx bxs-widget' ></i>
            <span class="links_name">Geners</span>
          </a>
        </li>
        <li>
          <a class="<?php echo e(request()->is('users') ? 'active' : ''); ?>" href="<?php echo e(route('users')); ?>">
            <i class='bx bx-user' ></i>
            <span class="links_name">Users</span>
          </a>
        </li>
        <li>
          <a class="<?php echo e(request()->is('skipgoogle') ? 'active' : ''); ?>" href="<?php echo e(route('skipg')); ?>">
            <i class='bx bx-bot' ></i>
            <span class="links_name">Skip Google Play</span>
          </a>
        </li>
        <li>
          <a class="<?php echo e(request()->is('subscrib') ? 'active' : ''); ?>" href="<?php echo e(route('subscrib')); ?>">
            <i class='bx bx-infinite' ></i>
            <span class="links_name">Bulk Movies</span>
          </a>
        </li>
         <li>
          <a class="<?php echo e(request()->is('tvbulk') ? 'active' : ''); ?>" href="<?php echo e(route('savetvshowsbulk')); ?>">
            <i class='bx bx-infinite' ></i>
            <span class="links_name">Bulk TV Shows</span>
          </a>
        </li>
        

      </ul>
  </div>
  <section class="home-section">
    <nav>
      <div class="sidebar-button">
        <i class='bx bx-menu sidebarBtn'></i>
        <span class="dashboard"><?php echo $__env->yieldContent('title','Admin'); ?></span>
      </div>

      <?php if(Session::has('loginId')): ?>
      <div class="button">
          <div class="text-icon">

              <a href="<?php echo e(route('logout')); ?>">
                <div class="input-box button">
                    <button form="tm" class="btn btn-danger">LOGOUT</button>
                </div>
            </a>
          </a>
          </div>
        </div>



      <?php else: ?>
      <a href="<?php echo e(route('login')); ?>">
          <span class="admin_name">Login</span>

      </a>
      <?php endif; ?>
    </nav>

    <?php echo $__env->yieldContent('contant'); ?>


  </section>

  <script src="<?php echo e(asset('asset/home/js/index.js')); ?>"></script>
  <script src="<?php echo e(asset('asset/home/js/movie.js')); ?>"></script>
  <script src="<?php echo e(asset('asset/home/js/textboxlimit.js')); ?>"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" ></script>



</body>
</html>
<?php /**PATH /home1/hypering/jseries.hyperwatching.com/resources/views/home.blade.php ENDPATH**/ ?>