<?php $__env->startSection('title', 'USERS'); ?>

<?php $__env->startSection('contant'); ?>



    <div class="container-movies">
        <main>


            <div class="all-movies">

                <section class="movie-section">
                    <div class="sales-analytics">
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end black">

                            <div class="input-box button">
                                <button form="tm" class="fetch-btn" data-bs-toggle="modal" data-bs-target="#addGeners">Add
                                    User</button>
                            </div>


                        </div>



                </section>




            </div>

            <div class="container-fluid mt-5 bg-white p-4 rounded shadow">
                <div class="d-flex justify-content-between">
                    <div>
                        <h1>All USERS</h1>
                        <form action="" method="GET">
                            <?php echo csrf_field(); ?>
                            <div class="browse">

                                <input type="search" name="query" placeholder="search" class="record-search">

                            </div>
                        </form>
                    </div>
                    <div>
                        <span class="fs-6 badge rounded-pill text-bg-dark">
                            Total USERS : <?php echo e(count($users)); ?>

                        </span>
                    </div>

                </div>

                <table class="table mt-5">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Full Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Subscription</th>
                            <th scope="col">Options</th>
                        </tr>
                    </thead>

                    <?php if(isset($result)): ?>
                        <tbody>
                            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user['id']); ?></td>

                                    <td class="mytitle"><?php echo e($user['name']); ?></td>
                                    <td class="mytitle"><?php echo e($user['email']); ?></td>
                                    <td class="warning"><?php echo e($user['Subscription']); ?></td>
                                    <td class="btn-edit">
                                        <a href="<?php echo e(route('DeletUser', $user['id'])); ?>">
                                        <button class="btn">Delete</button>
                                        </a>

                                    </td>


                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    <?php else: ?>
                        <?php if(isset($users)): ?>
                            <tbody>

                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user['id']); ?></td>

                                    <td class="mytitle"><?php echo e($user['name']); ?></td>
                                    <td class="mytitle"><?php echo e($user['email']); ?></td>
                                    <td class="warning"><?php echo e($user['Subscription']); ?></td>

                                    <td class="btn-edit">
                                        <a href="<?php echo e(route('DeletUser', $user['id'])); ?>">
                                        <button class="btn">Delete</button>
                                        </a>

                                    </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </tbody>
                        <?php endif; ?>

                </table>

                <?php endif; ?>



            </div>
            <?php if(isset($result)): ?>
                <div class="mynav">
                    <?php echo e($result->links('pagination::bootstrap-4')); ?>

                </div>
            <?php else: ?>
                <div class="mynav">
                    <?php echo e($users->links('pagination::bootstrap-4')); ?>

                </div>
            <?php endif; ?>



        </main>


    </div>




    <div class="modal fade" id="addGeners" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">

                    <h1 class="modal-title fs-5" id="exampleModalLabel">Add User</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

                </div>

                <div class="modal-body">
                    <?php if($errors->any()): ?>
                        <div class="col-12">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <h4 class="textsucc"><?php echo e($error); ?></h4>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                    <form method="post" action="<?php echo e(route('AddUser')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="Name" class="col-form-label">Name</label>
                            <input type="text" class="form-control" id="Name" name="name">
                        </div>
                        <div class="mb-3">
                            <label for="Email" class="col-form-label">Email</label>
                            <input type="text" class="form-control" id="Email" name="email">
                        </div>
                        <div class="mb-3">
                            <label for="Password" class="col-form-label">Password</label>
                            <input type="password" class="form-control" id="Password" name="password">
                        </div>
                        <div class="mb-3">
                            <label for="Confirm" class="col-form-label">Confirm Password</label>
                            <input type="password" class="form-control" id="Confirm" >
                        </div>
                        <div  class="btn-edit">
                            <select name="Subscription">

                                <?php $__currentLoopData = json_decode('{"Free":"Free","Premium":"Premium"}', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionKey => $optionValu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option class="form-control" value="<?php echo e($optionKey); ?>"><?php echo e($optionValu); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="profil" class="col-form-label">Profil Image</label>
                            <input type="text" class="form-control" id="profil" name="profil" >
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Add User</button>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\laravel projects\anass\resources\views/layout/users.blade.php ENDPATH**/ ?>