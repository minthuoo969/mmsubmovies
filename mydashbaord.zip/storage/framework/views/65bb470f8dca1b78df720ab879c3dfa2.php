<?php $__env->startSection('title', 'MOVIE'); ?>

<?php $__env->startSection('contant'); ?>



    <div class="container-movies">
        <main>


            <div class="all-movies">

                <section class="movie-section">
                    <div class="sales-analytics">
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end black">
                            <a href="<?php echo e(route('addmovie')); ?>">
                                <div class="input-box button">
                                    <button form="tm" class="fetch-btn">Add Movie</button>
                                </div>
                            </a>

                        </div>

                        



                        



                </section>




            </div>

            <div class="container-fluid mt-5 bg-white p-4 rounded shadow">
                <div class="d-flex justify-content-between">
                    <div>
                        <h1>All Movies</h1>
                        <form action="" method="GET">
                            <?php echo csrf_field(); ?>
                            <div class="browse">

                                <input type="search" name="query" placeholder="search" class="record-search">

                            </div>
                        </form>
                    </div>
                    <div>
                        <span class="fs-6 badge rounded-pill text-bg-dark">
                            Total Movies : <?php echo e(count($allmovies)); ?>

                        </span>
                    </div>

                </div>

                <table class="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">##</th>
                            <th scope="col">Thumbnail</th>
                            <th scope="col">Name</th>
                            <th scope="col">Description</th>
                            <th scope="col">Status</th>
                        </tr>
                    </thead>

                    <?php if(isset($result)): ?>
                    <tbody>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user['id']); ?></td>
                                <td class="btn-edit">
                                    <div class="dropdown">
                                        <div class="select">
                                            <span class="selected">Options</span>
                                            <div class="caret"></div>
                                        </div>
                                        <ul class="menu">

                                            <li><a href="<?php echo e(route('editmoviecreate', $user['id'])); ?>">Edit
                                                    Movie</a></li>
                                            <li><a href="<?php echo e(route('showmoviemanager', $user['id'])); ?>">Manage
                                                    Videos</a></li>
                                            <li><a href="<?php echo e(route('deletmovie', $user['id'])); ?>">Delete</a></li>
                                        </ul>
                                    </div>
                                </td>
                                <td class="poster"><img src="<?php echo e($user['poster']); ?>" alt=""></td>
                                <td class="mytitle"><?php echo e($user['title']); ?></td>
                                <td><?php echo e($user['story']); ?></td>
                                <td class="warning"><?php echo e($user['place']); ?></td>


                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                    <?php else: ?>
                        <?php if(isset($allmovies)): ?>
                            <tbody>

                                <?php $__currentLoopData = $allmovies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user['id']); ?></td>
                                    <td class="btn-edit">
                                        <div class="dropdown">
                                            <div class="select">
                                                <span class="selected">Options</span>
                                                <div class="caret"></div>
                                            </div>
                                            <ul class="menu">

                                                <li><a href="<?php echo e(route('editmoviecreate', $user['id'])); ?>">Edit
                                                        Movie</a></li>
                                                <li><a href="<?php echo e(route('showmoviemanager', $user['id'])); ?>">Manage
                                                        Videos</a></li>
                                                <li><a href="<?php echo e(route('deletmovie', $user['id'])); ?>">Delete</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                    <td class="poster"><img src="<?php echo e($user['poster']); ?>" alt=""></td>
                                    <td class="mytitle"><?php echo e($user['title']); ?></td>
                                    <td><?php echo e($user['story']); ?></td>
                                    <td class="warning"><?php echo e($user['place']); ?></td>


                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </tbody>
                        <?php endif; ?>

                </table>

                <?php endif; ?>



            </div>
            <?php if(isset($result)): ?>
            <div class="mynav">
                <?php echo e($result->links('pagination::bootstrap-4')); ?>

            </div>
            <?php else: ?>
            <div class="mynav">
                <?php echo e($allmovies->links('pagination::bootstrap-4')); ?>

            </div>
            <?php endif; ?>



        </main>


    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\laravel projects\anass\resources\views/layout/movie.blade.php ENDPATH**/ ?>