<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">

          <h1 class="modal-title fs-5" id="exampleModalLabel">Add Season (<?php echo e($tv['title']); ?>)</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

        </div>

        <div class="modal-body">
            <?php if($errors->any()): ?>
            <div class="col-12">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h4 class="textsucc"><?php echo e($error); ?></h4>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
          <form method="post" action="<?php echo e(route('fetchallseason',$tv['id'])); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
              <label for="recipient-name" class="col-form-label">Season numbre</label>
              <input type="text" class="form-control" id="recipient-name" name="name">
            </div>
            <div class="mb-3">
              <label for="order" class="col-form-label">Order</label>
              <input type="number" class="form-control" id="order" name="order" min="1" max="50">
            </div>
            <div class="mb-3">
                <select name="status">

                    <?php $__currentLoopData = json_decode('{"Published":"Published","Unpublished":"Unpublished"}', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionKey => $optionValu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option class="form-control" value="<?php echo e($optionKey); ?>"><?php echo e($optionValu); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Add Season</button>
              </div>
          </form>
        </div>

      </div>
    </div>
  </div>
<?php /**PATH H:\laravel projects\anass\resources\views/demo.blade.php ENDPATH**/ ?>