<?php $__env->startSection('title', 'SKIP GOOGLE PLAY'); ?>

<?php $__env->startSection('contant'); ?>
    <div class="home-content">



        <div class="insideskip">


            <?php if($errors->any()): ?>
                <div class="col-12">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h4 class="textsucc"><?php echo e($error); ?></h4>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            <?php endif; ?>

            <form method="post" action="<?php echo e(route('saveinfo')); ?>">
                <?php echo csrf_field(); ?>

                <?php if(isset($data)): ?>
                    <div class="mb-3">
                        <label for="recipient-name" class="col-form-label">Text</label>
                        <input type="text" value="<?php echo e($data['text']); ?>" class="form-control" id="recipient-name"
                            name="text">
                    </div>
                    <div class="mb-3">
                        <label for="ver-name" class="col-form-label">Version</label>
                        <input type="number" value="<?php echo e($data['version']); ?>" class="form-control" id="ver-name"
                            name="version">
                    </div>
                    <div class="mb-3">
                        <label for="order" class="col-form-label">Show Empty Screen On Start ?</label>

                        <select name="status" >

                            <?php $__currentLoopData = json_decode('{"true":"true","false":"false"}'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionKey => $optionValu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option class="form-control" value="<?php echo e($optionKey); ?>"><?php echo e($optionValu); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                <?php else: ?>
                    <div class="mb-3">
                        <label for="recipient-name" class="col-form-label">Text</label>
                        <input type="text" class="form-control" id="recipient-name"
                            name="text">
                    </div>
                    <div class="mb-3">
                        <label for="ver-name" class="col-form-label">Version</label>
                        <input type="number"  class="form-control" id="ver-name"
                            name="version">
                    </div>
                    <div class="mb-3">
                        <label for="order" class="col-form-label">Show Empty Screen On Start ?</label>

                        <select name="status" >

                            <?php $__currentLoopData = json_decode('{"true":"true","false":"false"}', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionKey => $optionValu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option class="form-control" value="<?php echo e($optionKey); ?>"><?php echo e($optionValu); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>

                <?php endif; ?>
            </form>
        </div>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\laravel projects\anass\resources\views/layout/notifacation.blade.php ENDPATH**/ ?>