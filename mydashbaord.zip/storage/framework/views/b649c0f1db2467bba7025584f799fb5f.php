<?php $__env->startSection('title', 'Season Manager'); ?>

<?php $__env->startSection('contant'); ?>



    <div class="container-movies">
        <main>
<?php if($errors->any()): ?>
                <div class="col-12">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h4 class="textsucc"><?php echo e($error); ?></h4>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            <?php endif; ?>

            <div class="container-fluid mt-5 bg-white p-4 rounded shadow">
                <div class="d-flex justify-content-between">
                    <div>
                        <h1><?php echo e($tv['title']); ?></h1>
                    </div>
                    <div>
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end black">


                            <button type="button" class="btn btn-success" data-bs-toggle="modal"
                                data-bs-target="#exampleModal">Add Season</button>

                         <!-- <form id="tm" action="<?php echo e(route('getSeasonsFromTMDB',$tv['tmdb_id'])); ?>" method="get">
                            <?php echo csrf_field(); ?>
                            <div class="input-box button">
                             <button form="tm" class="fetch-btn">Bulk Seasons</button>
                            </div>
                          
                          </form>-->
                              

                        </div>

                    </div>

                </div>

                <table class="table ">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Options</th>
                            <th scope="col">Name</th>
                            <th scope="col">Episodes</th>
                            <th scope="col">status</th>
                        </tr>
                    </thead>


                    <?php if(isset($seasons)): ?>
                        <tbody>

                            <?php $__currentLoopData = $seasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $season): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($season['id']); ?></td>
                                    <td class="btn-edit">
                                        
                                        <a href="<?php echo e(route('showepisodes', $season['id'])); ?>">
                                            <button type="button" class="btn">Manage Episodes</button>


                                            <a href="<?php echo e(route('deletseason', $season['id'])); ?>">
                                                <button type="button" class="btn">Delete</button></a>
                                    </td>
                                    <td class="mytitle"><?php echo e($season['name']); ?></td>

                                    <?php

                                    $episdoecount = \App\Models\episodemodel::getepisodecount($tv['id'],$season['id']);
                                    ?>
                                    <td class="mytitle"><?php echo e($episdoecount); ?></td>
                                    <td class="warning"><?php echo e($season['status']); ?></td>


                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </tbody>
                    <?php endif; ?>

                </table>





            </div>




        </main>


    </div>
    <?php echo $__env->make('demo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/hypering/jseries.hyperwatching.com/resources/views/layout/tvshow/managerseason.blade.php ENDPATH**/ ?>