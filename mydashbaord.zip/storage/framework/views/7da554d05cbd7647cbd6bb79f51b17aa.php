<!DOCTYPE html>
<!-- Coding By CodingNepal - codingnepalweb.com -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>login | Jserie Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('asset/home/css/loginstyle.css')); ?>">
   </head>
<body>


  <div class="wrapper">

    <div class="top">
        <h2>LOGIN</h2>

    </div>

    <div class="mt-5">
        <?php if($errors->any()): ?>
            <div class="col-12">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div ><?php echo e($error); ?></div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <?php if(session()->has('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>
    </div>

    <form action="<?php echo e(route('login.post')); ?>" method="post">
        <?php echo csrf_field(); ?>
      <div class="input-box">
        <input type="text" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
      </div>
      <div class="input-box">
        <input type="password" placeholder="Password"  name="password" value="<?php echo e(old('password')); ?>">
      </div>


      <div class="input-box button">
        <input type="Submit" value="Login">
      </div>

    </form>
  </div>
  <div class="below">
    <div class="text">
        <h3>Crafted  by <a href="https://codecanyon.net/user/elkadianass"> ANASS CORP</a></h3>
      </div>
  </div>
</body>
</html>
<?php /**PATH /home1/hypering/jseries.hyperwatching.com/resources/views/Auth/login.blade.php ENDPATH**/ ?>