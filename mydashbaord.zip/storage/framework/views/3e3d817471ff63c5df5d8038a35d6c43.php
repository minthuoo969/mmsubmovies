<?php $__env->startSection('title', 'ADD MOVIE'); ?>

<?php $__env->startSection('contant'); ?>


    <div class="create-movie">

        <div class="top">
            <h4 class="textaround">Import Contents From TMDB</h4>
            <div class="fetch">
                <form id="tm" action="<?php echo e(route('getMovieFromTMDB')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="text"  name="tmdb" placeholder="Enter TMDB ID. Ex: 38846" id="tmdb"
                        value="<?php echo e(old('tmdb')); ?>" class="record-tmdb_id">



                    <div class="input-box button">
                        <button form="tm" class="fetch-btn">Fetch</button>
                    </div>

                </form>



            </div>
            <h3>Get IMDB ID from here : <a href="https://www.themoviedb.org"> TheMovieDB.org</a></h3>

            
            <?php if($errors->any()): ?>
                <div class="col-12">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h4 class="textsucc"><?php echo e($error); ?></h4>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            <?php endif; ?>

            <?php if(isset($akhta)): ?>
            <div class="alert alert-danger">
                <h4 class="textsucc"><?php echo e($akhta); ?></h4>
            </div>
        <?php endif; ?>
        </div>
        <form action="<?php echo e(route('createmovie')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="importdata">

                <?php if(isset($data)): ?>

                <div class="meddle">
                    <div class="container-movies-2">
                        <main>


                            <div class="all-movies">

                                <section class="movie-section">


                                    <div class="king-info">

                                        <div class="containertow">
                                            <div class="Movie-Info">
                                                <h2>Movie Info</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Title</b></h2>




                                                        <input type="text" name="title" class="record-tmdb_id"
                                                        <?php if($data['title'] ): ?>
                                                        value="<?php echo e($data['title']); ?>"

                                                    <?php endif; ?> value="<?php echo e(old('title')); ?>">

                                                </div>


                                                <div class="m-title">
                                                    <h3><b>Description</b></h2>



                                                        <textarea name="story" id="text-desc" rows="5" value="ddd"><?php if($data['overview']): ?> <?php echo e($data['overview']); ?> <?php endif; ?></textarea><p class="counter" id="result"></p>

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Geners</b></h2>

                                                        <p>add a comma after each tag</p>
                                                        <input type="text" name="gener"


                                                       <?php if(count($data['genres']) > 0): ?>



                                                       <?php $__currentLoopData = $data['genres']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleGenre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                       value="<?php echo e($singleGenre['name']); ?>"
                                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                                                       <?php endif; ?>



                                                            placeholder="action,comedy,horror.....">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Release Date</b></h2>


                                                        <input type="text" name="year"

                                                        value="<?php echo e(date('Y',strtotime($data['release_date']))); ?>"
                                                            placeholder="add year : 2024..." class="record-date">

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Country</b></h2>


                                                        <input type="text" name="country" value="<?php echo e(old('country')); ?>"
                                                            placeholder="usa,canada,japon..." class="record-date">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Age</b></h2>


                                                        <input type="text" name="age" placeholder="+13,+14,+18....."
                                                            class="record-date" value="<?php echo e(old('age')); ?>">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>TMDB ID</b></h2>


                                                        <input type="text" name="tmdbid" placeholder="264633..."
                                                            class="record-date" value="<?php echo e($data['id']); ?>">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Status</b></h2>


                                                        <select name="status">

                                                            <?php $__currentLoopData = json_decode('{"Published":"Published","Unpublished":"Unpublished"}', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionKey => $optionValu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($optionKey); ?>"><?php echo e($optionValu); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </select>

                                                </div>





                                            </div>
                                            <div class="Movie-Info-2">
                                                <h2>Additional Info</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Thumbnail</b></h2>

                                                        <div class="img-poster">
                                                            <img id="poster"
                                                                <?php if(isset($data['poster_path'])): ?> src=" https://www.themoviedb.org/t/p/w600_and_h900_face<?php echo e($data['poster_path']); ?>"
                                                            <?php else: ?>
                                                            src=" https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ngl2FKBlU4fhbdsrtdom9LVLBXw.jpg " <?php endif; ?>
                                                                alt="">


                                                        </div>
                                                        <div class="fetch">

                                                            <input type="text" name="poster" id="posterlink"
                                                            <?php if(isset($data['poster_path'])): ?> value=" https://www.themoviedb.org/t/p/w600_and_h900_face<?php echo e($data['poster_path']); ?>"
                                                            <?php endif; ?>

                                                                placeholder="Image URL (Best Fit = 500 x 750)"
                                                                class="record-poster">

                                                            <div class="input-box button">

                                                                <input id="setposter" class="fetch-btn" type="button"
                                                                    value="SET">

                                                            </div>
                                                        </div>
                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Poster</b></h2>

                                                        <div class="img-poster">
                                                            <img  class="cover" id="cover"
                                                                <?php if(isset($data['backdrop_path'])): ?> src=" https://www.themoviedb.org/t/p/w600_and_h900_face<?php echo e($data['backdrop_path']); ?>"
                                                            <?php else: ?>
                                                            src=" https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ngl2FKBlU4fhbdsrtdom9LVLBXw.jpg " <?php endif; ?>
                                                                alt="">



                                                        </div>
                                                        <div class="fetch">

                                                            <input type="text" name="cover" id="coverlink"
                                                            <?php if(isset($data['backdrop_path'])): ?> value=" https://www.themoviedb.org/t/p/w600_and_h900_face<?php echo e($data['backdrop_path']); ?>"
                                                            <?php endif; ?>

                                                                placeholder="Image URL (Best Fit = 2048 x 1152)"
                                                                class="record-poster">

                                                            <div class="input-box button">
                                                                <input id="setcover" class="fetch-btn" type="button"
                                                                    value="SET">

                                                            </div>

                                                        </div>
                                                </div>



                                            </div>
                                        </div>

                                    </div>




                                </section>



                            </div>



                        </main>


                    </div>
                </div>

                <?php else: ?>

                <div class="meddle">
                    <div class="container-movies-2">
                        <main>


                            <div class="all-movies">

                                <section class="movie-section">


                                    <div class="king-info">

                                        <div class="containertow">
                                            <div class="Movie-Info">
                                                <h2>Movie Info</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Title</b></h2>




                                                        <input type="text" name="title" class="record-tmdb_id" value="<?php echo e(old('title')); ?>">

                                                </div>


                                                <div class="m-title">
                                                    <h3><b>Description</b></h2>



                                                        <textarea name="story" id="text-desc" rows="5" value="ddd"><?php echo e(old('story')); ?></textarea><p class="counter" id="result"></p>

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Geners</b></h2>

                                                        <p>add a comma after each tag</p>
                                                        <input type="text" name="gener"







                                                       value="<?php echo e(old('gener')); ?>"









                                                            placeholder="action,comedy,horror.....">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Release Date</b></h2>


                                                        <input type="text" name="year"

                                                        value="<?php echo e(old('year')); ?>"
                                                            placeholder="add year : 2024..." class="record-date">

                                                </div>

                                                <div class="m-title">
                                                    <h3><b>Country</b></h2>


                                                        <input type="text" name="country" value="<?php echo e(old('country')); ?>"
                                                            placeholder="usa,canada,japon..." class="record-date">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Age</b></h2>


                                                        <input type="text" name="age" placeholder="+13,+14,+18....."
                                                            class="record-date" value="<?php echo e(old('age')); ?>">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>TMDB ID</b></h2>


                                                        <input type="text" name="tmdbid" placeholder="264633..."
                                                            class="record-date" value="<?php echo e(old('tmdbid')); ?>">

                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Status</b></h2>


                                                        <select name="status">

                                                            <?php $__currentLoopData = json_decode('{"Published":"Published","Unpublished":"Unpublished"}', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionKey => $optionValu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($optionKey); ?>"><?php echo e($optionValu); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </select>

                                                </div>





                                            </div>
                                            <div class="Movie-Info-2">
                                                <h2>Additional Info</h2>
                                                <hr>
                                                <div class="m-title">
                                                    <h3><b>Thumbnail</b></h2>

                                                        <div class="img-poster">
                                                            <img id="poster"

                                                            src=" https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ngl2FKBlU4fhbdsrtdom9LVLBXw.jpg "
                                                                alt="">


                                                        </div>
                                                        <div class="fetch">

                                                            <input type="text" name="poster" id="posterlink"
                                                                value="<?php echo e(old('poster')); ?>"
                                                                placeholder="Image URL (Best Fit = 500 x 750)"
                                                                class="record-poster">

                                                            <div class="input-box button">

                                                                <input id="setposter" class="fetch-btn" type="button"
                                                                    value="SET">

                                                            </div>
                                                        </div>
                                                </div>
                                                <div class="m-title">
                                                    <h3><b>Poster</b></h2>

                                                        <div class="img-poster">
                                                            <img  class="cover" id="cover"

                                                            src=" https://www.themoviedb.org/t/p/w600_and_h900_bestv2/ngl2FKBlU4fhbdsrtdom9LVLBXw.jpg "
                                                                alt="">



                                                        </div>
                                                        <div class="fetch">

                                                            <input type="text" name="cover" id="coverlink"
                                                                value="<?php echo e(old('cover')); ?>"
                                                                placeholder="Image URL (Best Fit = 2048 x 1152)"
                                                                class="record-poster">

                                                            <div class="input-box button">
                                                                <input id="setcover" class="fetch-btn" type="button"
                                                                    value="SET">

                                                            </div>

                                                        </div>
                                                </div>



                                            </div>
                                        </div>

                                    </div>




                                </section>



                            </div>



                        </main>


                    </div>
                </div>
                <?php endif; ?>

                <div class="addmoviebtn">

                    <button class="fetch-btn">Add Movie</button>

                </div>
            </div>




        </form>
    </div>




    <script>
        const setposter = document.getElementById('setposter');
        var posterlink = document.getElementById('posterlink');
        var poster = document.getElementById('poster');

        const setcover = document.getElementById('setcover');
        var coverlink = document.getElementById('coverlink');
        var cover = document.getElementById('cover');



        setposter.addEventListener('click', () => {

            poster.src = posterlink.value;

        });


        setcover.addEventListener('click', () => {

            cover.src = coverlink.value;

        });
    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\laravel projects\anass\resources\views/layout/addmovie.blade.php ENDPATH**/ ?>