<?php $__env->startSection('title', 'DASHBOARD'); ?>

<?php $__env->startSection('contant'); ?>

    <div class="container">
        <main>


            <div class="insights">

                <div class="sales">



                    <div class="middle">
                        <div class="left">

                            <h3>TOTAL MOVIE</h3>
                            <h1><?php echo e($moviecount); ?></h1>

                        </div>

                        <span class="material-symbols-sharp">movie</span>

                    </div>
                </div>

                <!--- End OF MOVIES----->
                <div class="income">



                    <div class="middle">
                        <div class="left">

                            <h3>TOTAL SERIES</h3>
                            <h1><?php echo e($tvcount); ?></h1>

                        </div>

                        <span class="material-symbols-sharp">tv</span>

                    </div>
                </div>

                <!--- End OF SERIES----->
                <div class="expencecs">



                    <div class="middle">
                        <div class="left">

                            <h3>TOTAL USERS</h3>
                            <h1><?php echo e($usercount); ?></h1>

                        </div>
                        <span class="material-symbols-sharp">person</span>

                    </div>
                </div>

                <!--- End OF users----->
                <div class="expencecs">



                    <div class="middle">
                        <div class="left">

                            <h3>TOTAL VIDEOS</h3>
                            <h1><?php echo e($videocount); ?></h1>

                        </div>
                        <span class="material-symbols-sharp">all_inclusive</span>

                    </div>
                </div>

                <!--- End OF PRIMUME----->

            </div>

            <!--- End OF insights----->


            <div class="recent-orders">
                <h2>Most viewed Movies Today</h2>
                <table class="table mt-2">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>View</th>
                            <th>TMDB ID</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $movievisitedtoday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user['id']); ?></td>
                                <td><?php echo e($user['title']); ?></td>
                                <td><?php echo e($user['visit_count_total']); ?></td>

                                <td><?php echo e($user['tmdb_id']); ?></td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="recent-orders">
                <h2>Most viewed TV SHOWS Today</h2>
                <table class="table mt-2">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>View</th>
                            <th>TMDB ID</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tvshowsvisitedtoday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user['id']); ?></td>
                                <td><?php echo e($user['title']); ?></td>
                                <td><?php echo e($user['visit_count_total']); ?></td>
                                <td><?php echo e($user['tmdb_id']); ?></td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="containertow">
                <div class="recent-orders">
                    <h2>Most viewed Tv Shows</h2>
                    <table class="table mt-2">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>View</th>
                                <th>TMDB ID</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $mosttvshowsvisited; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user['id']); ?></td>
                                    <td><?php echo e($user['title']); ?></td>
                                    <td><?php echo e($user['visit_count_total']); ?></td>
                                    <td><?php echo e($user['tmdb_id']); ?></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="recent-orders">
                    <h2>Most viewed Movies</h2>
                    <table class="table mt-2">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Title</th>
                                <th>View</th>
                                <th>TMDB ID</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $mostmovievisted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user['id']); ?></td>
                                    <td><?php echo e($user['title']); ?></td>
                                    <td><?php echo e($user['visit_count_total']); ?></td>
                                    <td><?php echo e($user['tmdb_id']); ?></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>

            <div class="recent-orders">
                <h2>New Users</h2>
                <table class="table mt-2">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Full Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Subscription</th>
                        </tr>
                    </thead>



                    <tbody>
                        <?php $__currentLoopData = $allusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                            <tr>
                                <td><?php echo e($user['id']); ?></td>

                                <td class="mytitle"><?php echo e($user['name']); ?></td>
                                <td class="mytitle"><?php echo e($user['email']); ?></td>
                                <td class="warning"><?php echo e($user['Subscription']); ?></td>


                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>


                </table>
            </div>
        </main>


    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\laravel projects\anass\resources\views/layout/dashbaord.blade.php ENDPATH**/ ?>